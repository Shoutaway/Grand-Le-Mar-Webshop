jQuery(document).ready(function(){
  //   jQuery(".productOptions").find(".selector-wrapper").each(function(){
  //     var currentOptioName = jQuery(this).find("select").attr("option-name");
  //     jQuery(this).find("select").prepend('<option value="" disabled="disabled" selected="selected">Select '+currentOptioName+'</option>');
  //     jQuery("button#AddToCart-product-template").attr("disabled","disabled");
  //     jQuery("button#AddToCart-product-template span").find("UNAVAILABLE");
  //   });
  jQuery('form#contact_form[action="/contact#contact_form"] .errors').html("<p>INVALID EMAIL<img error='error-close-email' src='https://cdn.shopify.com/s/files/1/2574/2560/files/newsletter-close.png?7631' /></p>");
  /*======================================
  			Custom JS drawer
  ======================================*/
  jQuery(document).on("click", "div#close-search-drawer-nw", function(){
    jQuery("#grand-le-mar-trigger-click").click();
  });
  jQuery(document).on("click", "div#close-search-drawer-nwd", function(){
    jQuery("div#language-convertor-c").click();
  });


  /*======================================
  			Custom Search Script
 ======================================*/
  // appending a hidden div no results.
  jQuery("form.search.search-bar__form").append('<p id="results-0-not-found" class="results-0 not found" style="display: none;"><span>NO RESULTS</span></p>');

  // Search Result based on conditions
  jQuery(document).on("keypress", "input#search_h_input-input", function(){
    var currentText = jQuery(this).val();
    var currentTextTrim = jQuery.trim(currentText);
    var textLengthUnderDiv = jQuery(this).closest("form.search.search-bar__form").find("ul.search-results").html();
    var newtextLengthUnderDiv = jQuery.trim(textLengthUnderDiv);
    // alert("input text length" + currentTextTrim.length);
    // alert("result length" + newtextLengthUnderDiv.length);
    // if(newtextLengthUnderDiv.length < 1 || jQuery("form.search.search-bar__form").find("ul.search-results").attr("style") == "position: absolute; left: 0px; top: 84px; display: none;"){
    // }else if(newtextLengthUnderDiv.length > 0 || jQuery("form.search.search-bar__form").find("ul.search-results").attr("style") == "position: absolute; left: 0px; top: 84px; display: block;"){

    setTimeout(function(){
      var setTimeoutForStyleAttr = jQuery("form.search.search-bar__form").find("ul.search-results").attr("style");
      if(setTimeoutForStyleAttr == "position: absolute; left: 0px; top: 84px; display: none;" || setTimeoutForStyleAttr == "position: absolute; left: 0px; top: 62px; display: none;"){
        jQuery("p#results-0-not-found").show();
        jQuery("p#results-0-not-found").addClass("show-now-ye");
        jQuery("p#results-0-not-found").removeClass("hide-now-ye");
      }else if(setTimeoutForStyleAttr == "position: absolute; left: 0px; top: 84px; display: block;" || setTimeoutForStyleAttr == "position: absolute; left: 0px; top: 62px; display: block;"){
        jQuery("p#results-0-not-found").hide();
        jQuery("p#results-0-not-found").removeClass("show-now-ye");
        jQuery("p#results-0-not-found").addClass("hide-now-ye");
      }
    }, 1000);
  });

  // Language Translator
  jQuery(document).on("click", "div#language-convertor-c", function(){ 
    jQuery("div#SearchDrawerInner0").toggleClass("is-transitioning");
    jQuery("div#SearchDrawerInner0").closest("body").toggleClass("js-drawer-custom-top js-drawer-open");
    //jQuery("div#SearchDrawerInner0").closest("html").toggleClass("js-drawer-custom-top");
    setTimeout(function(){
      jQuery("div#SearchDrawerInner0").removeClass("is-transitioning");   
    }, 1000);
    jQuery("div#SearchDrawerInner0").toggleClass("translate-type-changer");
  });



  jQuery(document).mouseup(function(e){
    var container = jQuery("#SearchDrawerInner0");
    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0){
      jQuery("body").removeClass("js-drawer-custom-top js-drawer-open");
    }
  });
});



/*=================================================================
                        ON LOAD SCRIPTS
=================================================================*/
jQuery(window).on("load", function(){
  /*======================================
  Product Page Select & Submit
  ======================================*/
  jQuery("div#shopify-section-product-template").find("form.product-form-product-template select#SingleOptionSelector-0 option").each(function(){
    jQuery(this).removeAttr("selected");
    if(jQuery(this).find("option:nth-child(1)").text() == "Select Size"){
      setTimeout(function(){
        jQuery(this).find("option:nth-child(1)").attr("selected");
      }, 500);
    }
  });

  jQuery("div#shopify-section-product-template").find("form.product-form-product-template select#SingleOptionSelector-0 option").each(function(){
    jQuery(this).removeAttr("selected");
    if(jQuery(this).find("option:nth-child(1)").text() == "Select Size"){
      setTimeout(function(){
        jQuery(this).find("option:nth-child(1)").attr("selected");
      }, 500);
    }
  });

  jQuery("div#shopify-section-product-template").find("form.product-form-product-template select#SingleOptionSelector-0 option").each(function(){
    jQuery(this).removeAttr("selected");
    if(jQuery(this).find("option:nth-child(1)").text() == "Select Size"){
      setTimeout(function(){
        jQuery(this).find("option:nth-child(1)").attr("selected");
      }, 500);
    }
  });


  jQuery("div#shopify-section-product-template").find("form.product-form-product-template select#SingleOptionSelector-0").each(function(){
    if(jQuery(this).find("option:nth-child(1)").text()=="Select Size" || jQuery(this).find("option:nth-child(1)").text()=="Select Size"){
      jQuery("div#shopify-section-product-template").find("form.product-form-product-template button#AddToCart-product-template").attr("disabled","disabled");
      jQuery("span#AddToCartText-product-template").text("UNAVAILABLE");
    }
  });
  jQuery("div#shopify-section-product-template").find("form.product-form-product-template select#SingleOptionSelector-1").each(function(){
    if(jQuery(this).find("option:nth-child(1)").text()=="Select Size" || jQuery(this).find("option:nth-child(1)").text()=="Select Size"){
      jQuery("div#shopify-section-product-template").find("form.product-form-product-template button#AddToCart-product-template").attr("disabled","disabled");
      jQuery("span#AddToCartText-product-template").text("UNAVAILABLE");
    }
  });
  jQuery("div#shopify-section-product-template").find("form.product-form-product-template select#SingleOptionSelector-2").each(function(){
    if(jQuery(this).find("option:nth-child(1)").text()=="Select Size" || jQuery(this).find("option:nth-child(1)").text()=="Select Size"){
      jQuery("div#shopify-section-product-template").find("form.product-form-product-template button#AddToCart-product-template").attr("disabled","disabled");
      jQuery("span#AddToCartText-product-template").text("UNAVAILABLE");
    }
  });

});




jQuery(window).on("load",function(){
  jQuery("#product-page--form--custom").removeAttr("style");
  jQuery(".productOptions").find(".selector-wrapper").each(function(){
    var currentOptioName = jQuery(this).find("select").attr("option-name");
    if(currentOptioName){
      jQuery(this).find("select").prepend('<option value="" disabled="disabled" selected="selected">Select '+currentOptioName+'</option>');
      jQuery("button#AddToCart-product-template").attr("disabled","disabled");
      jQuery("button#AddToCart-product-template span").find("UNAVAILABLE");
    }else{
      /*jQuery(this).find("select").prepend('<option value="" disabled="disabled" selected="selected">Select Country</option>');*/
      jQuery(this).find("select option[data-viva]").attr('selected','selected');
	  jQuery(this).find("select option[data-viva]").prop('selected','selected');
	console.log('option name commented!! Grand Vendor TSJS');
      jQuery(this).find("option").each(function(){
        var optionTextCurrent01 = jQuery(this).text();
        if(optionTextCurrent01=="Select mlveda_country"){
          jQuery(this).remove();
        }
      });
    }
  });
});