/*=================================================
          -----------TS-FitFinder-Timber.js.liquid-----------
    =================================================*/

/*===================================================
          -----------TS-FitFinder-Timber.js.liquid-----------
    ===================================================*/
// on ready scripts
jQuery(document).ready(function(){
  var popupclicked= 0;
  jQuery("input#input-type-HTAY-main").attr('maxlength','3');
  jQuery("input#input-type-WIYW-main").attr('maxlength','3');
  jQuery("input#input-type-HORU-main").attr('maxlength','2');

  jQuery(document).on("click", "a.popup-modal-ts", function(e){
    console.log('popup Opened');
    e.preventDefault();
    jQuery(".TS-FitFinder-Outer").show(); // open pop-up
    jQuery(this).closest("body").addClass("overflow---hidden"); // open pop-up
    jQuery(this).closest("html").addClass("overflow---hidden"); // open pop-up
    jQuery("input#input-type-HTAY-main").focus();

    if(popupclicked == '0'){
      /* Initialise Slider */
      jQuery(".fitslider").slick({
        infinite: true,
        vertical: true,
        verticalSwiping: true,
        slidesToShow: 1,
        infinite: true,
        dots:false
      });

      if(jQuery(window).width() < 768){
        /* set default input values before swiper slides */
        jQuery('div#FitFinder-centimeter .how_tall_wrapper .measure_box input[type="text"]').val('0');
        jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts .how_tall_wrapper .measure_box input[type="text"]').val('0');
        jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts .how_tall_wrapper .measure_box input[type="text"]').val('0');
        console.log('Default Value is set if window is less than 768');
      }

      popupclicked = 1;


    }

    setTimeout(function(){
      jQuery(".GTS-FitFinder-Inner").remove();
      console.log('Popup Active Now!!!');
    }, 1000);
  });
  jQuery(document).on("click", "img.FitFinder-Close", function(){
    jQuery(".TS-FitFinder-Inner").prepend('<div class="GTS-FitFinder-Inner"><div class="GTS-FitFinder-Inner001"><img src="https://cdn.shopify.com/s/files/1/2574/2560/files/loader.gif?56651"></div></div>');
    jQuery(".TS-FitFinder-Outer").hide(); // close pop-up
    jQuery(this).closest("body").removeClass("overflow---hidden"); // open pop-up
    jQuery(this).closest("html").removeClass("overflow---hidden"); // open pop-up
  });

  jQuery('.TSFF-CS').on('click',function(eevnt){
    eevnt.preventDefault();
    jQuery(".TS-FitFinder-Inner").prepend('<div class="GTS-FitFinder-Inner"><div class="GTS-FitFinder-Inner001"><img src="https://cdn.shopify.com/s/files/1/2574/2560/files/loader.gif?56651"></div></div>');
    jQuery(".TS-FitFinder-Outer").hide(); // close pop-up
    jQuery(this).closest("body").removeClass("overflow---hidden"); // open pop-up
    jQuery(this).closest("html").removeClass("overflow---hidden"); // open pop-up
  });

  // how tall you are? pop-up section script
  // unit based cookies for height
  jQuery(document).on("click", "label.switch-HTAY", function(){
    if(jQuery(this).find("input").is(":checked")){
      jQuery("#input-type-HTAY-main").attr("placeholder","inches");
      jQuery(this).closest("label").find("input").val("-in");
      jQuery(this).closest("label").attr("unit", "in");
      Cookies.set('height-unit', 'in');
      Cookies.set('height-value', jQuery("input#input-type-HTAY-main").val()+'in');
      /*
                      var heightVal = jQuery("input#input-type-HTAY-main").val();
                      if(heightVal < 163) { var heightResult = "smaller"; }
                      if(heightVal > 191) { var heightResult = "larger"; }
                      if(heightVal < 163 && heightVal > 191) { var heightResult = "Regular"; }
                      Cookies.set('result-value', heightResult);
                      */
    }
    if(!jQuery(this).find("input").is(":checked")){
      jQuery("#input-type-HTAY-main").attr("placeholder","centimeters");
      jQuery(this).closest("label").find("input").val("-cm");
      jQuery(this).closest("label").attr("unit", "cm");
      Cookies.set('height-unit', 'cm');
      Cookies.set('height-value', jQuery("input#input-type-HTAY-main").val()+'cm');
      /*
                      var heightVal = jQuery("input#input-type-HTAY-main").val();
                      if(heightVal < 163) { var heightResult = "smaller"; }
                      if(heightVal > 191) { var heightResult = "larger"; }
                      if(heightVal < 163 && heightVal > 191) { var heightResult = "Regular"; }
                      Cookies.set('result-value', heightResult);
                      */
    }
  });

  // What is your weight? pop-up section script
  // unit based cookies for weight
  jQuery(document).on("click", "label.switch-WIYW", function(){
    if(jQuery(this).find("input").is(":checked")){
      jQuery("#measure_box_1").show();
      jQuery("#input-type-WIYW-main").attr("placeholder","lbs");
      jQuery(this).closest("label").find("input").val("-lbs");
      jQuery(this).closest("label").attr("unit", "lbs");
      Cookies.set('weight-unit', 'lbs');
      Cookies.set('weight-value', jQuery("input#input-type-WIYW-main").val()+'lbs');
      /*var weightVal = jQuery("input#input-type-WIYW-main").val();
                      if(weightVal > 65 && weightVal < 74) {
                        if(weightVal == '66') { var resultVal = [{'size1':46,'prob1':'55%','size2':44,'prob2':'45%'}] }
                        if(weightVal == '67') { var resultVal = [{'size1':46,'prob1':'58%','size2':44,'prob2':'42%'}] }
                        if(weightVal == '68') { var resultVal = [{'size1':46,'prob1':'61%','size2':48,'prob2':'39%'}] }
                        if(weightVal == '69') { var resultVal = [{'size1':46,'prob1':'80%','size2':48,'prob2':'20%'}] }
                        if(weightVal == '70') { var resultVal = [{'size1':46,'prob1':'73%','size2':48,'prob2':'27%'}] }
                        if(weightVal == '71') { var resultVal = [{'size1':46,'prob1':'61%','size2':48,'prob2':'39%'}] }
                        if(weightVal == '72') { var resultVal = [{'size1':46,'prob1':'58%','size2':44,'prob2':'42%'}] }
                        if(weightVal == '73') { var resultVal = [{'size1':46,'prob1':'55%','size2':44,'prob2':'45%'}] }
                      }
                      Cookies.set('result-value', JSON.stringify(resultVal));*/
    }
    if(!jQuery(this).find("input").is(":checked")){
      jQuery("#measure_box_1").hide();
      jQuery("#input-type-WIYW-main").attr("placeholder","kg");
      jQuery(this).closest("label").find("input").val("-kg");
      jQuery(this).closest("label").attr("unit", "kg");
      Cookies.set('weight-unit', 'kg');
      Cookies.set('weight-value', jQuery("input#input-type-WIYW-main").val()+'kg');

    }
  });



  // updating cookie value on keyup of input type
  //       jQuery(document).on("keyup", "input.input-type-HTAY", function(){
  //         var howTallYouAre = jQuery(this).val();
  //         var howTallYouAre_Unit = Cookies.get('height-unit');
  //         Cookies.set('height-value', howTallYouAre+howTallYouAre_Unit);
  //       });

  // updating cookie value on keyup of input type
  jQuery(document).on("keyup", "input.input-type-WIYW", function(){
    var howTallYouAreweighta = jQuery(this).val();
    var howTallYouAre_Unitweighta = Cookies.get('weight-unit') 
    Cookies.set('weight-value', howTallYouAreweighta+howTallYouAre_Unitweighta);
  });

  // updating cookie value on keyup of input type
  jQuery(document).on("keyup", "input.input-type-HORU", function(){
    var howTallYouAreAge = jQuery(this).val(); 
    Cookies.set('age-value', howTallYouAreAge);
  });
  // How tall are you? [Input Field Validation]
  //called when key is pressed in textbox
  jQuery("input#input-type-HTAY-main").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("#input-type-WIYW-main").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13  && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("#input-type-HORU-main").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("input.measure_box__a_1").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("input.measure_box_b_2").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("input#input-type-HORU-main").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("input.measure_box_1, input.measure_box_2, input.measure_box_3").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("input.measure_box_1_wiyw, input.measure_box_2_wiyw, input.measure_box_3_wiyw").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });
  jQuery("input.measure_box_1_horu, input.measure_box_2_horu").keypress(function (e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 13 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $("#errmsg").html("Digits Only").show().fadeOut("slow");
      return false;
    }
  });



  // show and hide pop-up content
  // navigation point based condition
  jQuery(document).on("click", ".round-all", function(){
    jQuery(".TS-FitFinder-Main").find(".TS-FitFinder-HTAY").hide();
    jQuery(".TS-FitFinder-Main").find(".TS-FitFinder-HTAY").removeClass("FitFinder-Active");
    //jQuery(".TS-FitFinder-Main").find(".TS-FitFinder-HTAY").removeAttr("data-move");
    jQuery(".steps-HTAY").find(".round-all").removeClass("active");
    jQuery(this).addClass("active");
    var currentDataNavStep  = jQuery(this).attr("data-step");
    jQuery(this).closest(".TS-FitFinder-Main").find(".TS-FitFinder-HTAY").each(function(){
      var mainOuterDataAttr = jQuery(this).attr("data-step");
      //console.log(jQuery.trim(currentDataNavStep) + " & " + jQuery.trim(mainOuterDataAttr));
      if(jQuery.trim(currentDataNavStep) == jQuery.trim(mainOuterDataAttr)){
        jQuery(this).addClass("FitFinder-Active");
        setTimeout(function(){
          console.log('update data-active-slide value');
          var stepNum = jQuery('.TS-FitFinder-HTAY.FitFinder-Active').attr('data-step');
          jQuery('.TS-FitFinder-Main').attr('data-active-slide',stepNum);
        },100);
        //jQuery(this).attr("data-move", "TS-FitFinder");
        jQuery(this).show();
      }
    });
  });

  // images based radio button condition 
  jQuery(document).on("click", "input.checkbox-BS", function(){
    jQuery(".TS-FitFinder-HTAY").find("img").removeClass("img-with-border-BS");
    var bellyShapeChecked = jQuery(this).find("input").is(":checked");
    jQuery(this).closest("label.switch-BS").find("img").addClass("img-with-border-BS");
    console.log('the value selected is :- '+ jQuery(this).attr("shape-type"));
    Cookies.set("belly_shape_type", jQuery(this).attr("shape-type"));
    jQuery('.steps-HTAY .round-all[data-step="step-4"]').trigger('click');
  });
  jQuery(document).on("click", "input.checkbox-SW", function(){
    jQuery(".TS-FitFinder-HTAY").find("img").removeClass("img-with-border-SW");
    var bellyShapeChecked = jQuery(this).find("input").is(":checked");
    jQuery(this).closest("label.switch-SW").find("img").addClass("img-with-border-SW");
    console.log('the value selected is :- '+ jQuery(this).attr("shape-type"));
    Cookies.set("shoulder_shape_type", jQuery(this).attr("shape-type"));
    jQuery('.steps-HTAY .round-all[data-step="step-5"]').trigger('click');
    jQuery('.TS-FitFinder-HTAY.TS-5 .desktop--only-ts input').focus();
  });

  // range slider script cookies based
  jQuery(document).on("change", "#range-main-input-FP", function(){
    //jQuery(".TS-FitFinder-HTAY").find("img").removeClass("img-with-border-BS");
    var rangeValue = jQuery(this).val();
    if(rangeValue=="1"){
      jQuery(this).attr("Fit-Pref", "TIGHT");
      jQuery(this).attr("data-choice", "TIGHT");
      Cookies.set('f_preference_value', "TIGHT");
    }
    if(rangeValue=="2"){
      jQuery(this).attr("Fit-Pref", "LITTLE TIGHT");
      jQuery(this).attr("data-choice", "LITTLE TIGHT");
      Cookies.set('f_preference_value', "LITTLE-TIGHT");
    }
    if(rangeValue=="3"){
      jQuery(this).attr("Fit-Pref", "NORMAL");
      jQuery(this).attr("data-choice", "NORMAL");
      Cookies.set('f_preference_value', "NORMAL");
    }
    if(rangeValue=="4"){
      jQuery(this).attr("Fit-Pref", "LITTLE LOOSE");
      jQuery(this).attr("data-choice", "LITTLE LOOSE");
      Cookies.set('f_preference_value', "LITTLE-LOOSE");
    }
    if(rangeValue=="5"){
      jQuery(this).attr("Fit-Pref", "LOOSE");
      jQuery(this).attr("data-choice", "LOOSE");
      Cookies.set('f_preference_value', "LOOSE");
    }
  });

  /*================================================================
                                        START BASED ON SIZE
                ================================================================*/
  jQuery(document).on("keyup", "input.input-type-HTAY", function(){
    var firstpopupValue = jQuery(this).val();
    var howTallYouAre = firstpopupValue;
    console.log(firstpopupValue);
    var howTallYouAre_Unit = Cookies.get('height-unit');
    Cookies.set('height-value', howTallYouAre+howTallYouAre_Unit);
    var currentUnitForTallerShorter = jQuery(this).closest(".TS-FitFinder-HTAY").find("label").attr("unit");
    /*if(howTallYouAre < 163) { var heightResult = 'smaller'; }
                    if(howTallYouAre > 191) { var heightResult = 'larger'; }
                    if(howTallYouAre < 163 && howTallYouAre > 191) { var heightResult = 'Regular'; }
                    Cookies.set('result-value', 'heightResult');*/
    // If Small --------------- Inches & Centimeters ---------------] 
    // If Regular Size

    // If CENTIMETERS
    if(!jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
      if(jQuery.trim(howTallYouAre)> 100){

        jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');


        if(jQuery.trim(howTallYouAre_Unit) == "cm" && (jQuery.trim(howTallYouAre) < parseInt(163) || jQuery.trim(howTallYouAre) == parseInt(163))){
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"S");
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","S");
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
          Cookies.set('Popup_First_Output', "S-"+howTallYouAre+"-CM");
          console.log('less than 163 Small');
        }
        if(jQuery.trim(howTallYouAre_Unit) == "cm" && (jQuery.trim(howTallYouAre) > parseInt(163) && jQuery.trim(howTallYouAre) < parseInt(188))){
          console.log('D-R 1');
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"R");
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","R");
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
          Cookies.set('Popup_First_Output', "R-"+howTallYouAre+"-CM");
          console.log('greater than 163 less than 188 Regular');
        }
        if(jQuery.trim(howTallYouAre_Unit) == "cm" && (jQuery.trim(howTallYouAre) > parseInt(188) || jQuery.trim(howTallYouAre) == parseInt(188))){
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"L");
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","L");
          jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
          Cookies.set('Popup_First_Output', "L-"+howTallYouAre+"-CM");
          console.log('greater than 188 Large');
        }
      }else{
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    }

    //  If INCHES
    if(jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
      //console.log("Checked Inches howTallYouAre "+howTallYouAre);
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (jQuery.trim(howTallYouAre) < parseInt(64) || jQuery.trim(howTallYouAre) == parseInt(64))){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "S-"+howTallYouAre+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (jQuery.trim(howTallYouAre) > parseInt(64) && jQuery.trim(howTallYouAre) < parseInt(74))){
        console.log('D-R 2');
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "R-"+howTallYouAre+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (jQuery.trim(howTallYouAre) > parseInt(74) || jQuery.trim(howTallYouAre) == parseInt(74))){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "L-"+howTallYouAre+"-IN");
      }
    }
  });


  jQuery(document).on("click", "label.switch-HTAY.step-1", function(){
    var howTallYouAre1 = parseInt(jQuery(this).closest(".TS-FitFinder-HTAY").find(".input-type-HTAY").val());
    var howTallYouAre_Unit1 = Cookies.get('height-unit');
    Cookies.set('height-value', howTallYouAre1+howTallYouAre_Unit1);
    var currentUnitForTallerShorter1 = jQuery(this).attr("unit");
    /*if(howTallYouAre1 < 163) { var heightResult = 'smaller'; }
                    if(howTallYouAre1 > 191) { var heightResult = 'larger'; }
                    if(howTallYouAre1 < 163 && howTallYouAre1 > 191) { var heightResult = 'Regular'; }
                    Cookies.set('result-value', heightResult);*/

    //console.log(currentUnitForTallerShorter1);
    // If Small --------------- Inches & Centimeters ---------------] 
    // If CENTIMETERS
    if(!jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
      if (jQuery(window).width() < 768) {
        jQuery("div#FitFinder-centimeter").show();
        jQuery("div#FitFinder-inches").hide();
      }
      if(jQuery.trim(howTallYouAre_Unit1) == "cm" && (jQuery.trim(howTallYouAre1) < 163 || jQuery.trim(howTallYouAre1) == 163)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(currentUnitForTallerShorter1+"-"+howTallYouAre1+"-"+"S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","S");
        Cookies.set('Popup_First_Output', "S-"+howTallYouAre1+"-CM");
      }
      if(jQuery.trim(howTallYouAre_Unit1) == "cm" && (jQuery.trim(howTallYouAre1) > 163 && jQuery.trim(howTallYouAre1) < 188)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(currentUnitForTallerShorter1+"-"+howTallYouAre1+"-"+"R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","R");
        Cookies.set('Popup_First_Output', "R-"+howTallYouAre1+"-CM");
      }
      if(jQuery.trim(howTallYouAre_Unit1) == "cm" && (jQuery.trim(howTallYouAre1) > 188 || jQuery.trim(howTallYouAre1) == 188)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(currentUnitForTallerShorter1+"-"+howTallYouAre1+"-"+"L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","L");
        Cookies.set('Popup_First_Output', "L-"+howTallYouAre1+"-CM");
      }
    }
    // If INCHES
    if(jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
      if(jQuery(window).width() < 767){
        jQuery("div#FitFinder-centimeter").hide();
        jQuery("div#FitFinder-inches").show();
      }
      if(jQuery.trim(howTallYouAre_Unit1) == "in" && (jQuery.trim(howTallYouAre1) < 64 || jQuery.trim(howTallYouAre1) == 64)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(currentUnitForTallerShorter1+"-"+howTallYouAre1+"-"+"S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","S");
        Cookies.set('Popup_First_Output', "S-"+howTallYouAre1+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit1) == "in" && (jQuery.trim(howTallYouAre1) > 64 && jQuery.trim(howTallYouAre1) < 74)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(currentUnitForTallerShorter1+"-"+howTallYouAre1+"-"+"R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","R");
        Cookies.set('Popup_First_Output', "R-"+howTallYouAre1+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit1) == "in" && (jQuery.trim(howTallYouAre1) > 74 || jQuery.trim(howTallYouAre1) == 74)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(currentUnitForTallerShorter1+"-"+howTallYouAre1+"-"+"L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","L");
        Cookies.set('Popup_First_Output', "L-"+howTallYouAre1+"-IN");
      }
    }
  });

  /*================================================================
                                        END BASED ON SIZE
                ================================================================*/


  /*================================================================
                                          BASED ON WEIGHT
                ================================================================*/
  jQuery(document).on("keyup", "input.input-type-WIYW", function(){
    //alert("What is your weight?");
    var firstpopupValue = jQuery(this).val();
    var whatIsYOurWeight = parseInt(firstpopupValue);
    var whatIsYOurWeight_Unit = Cookies.get('weight-unit');
    Cookies.set('weight-value', whatIsYOurWeight+whatIsYOurWeight_Unit);
    var currentUnitForTallerShorter = jQuery(this).closest(".TS-FitFinder-HTAY").find("label").attr("unit");
    // If LBS
    if(jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-WIYW").is(":checked")){
      if(jQuery.trim(whatIsYOurWeight_Unit) == "lbs"){
        jQuery("#measure_box_2").hide();
        console.log("whatIsYOurWeight_Unit lbs"+whatIsYOurWeight_Unit);

        if(whatIsYOurWeight > 143 && whatIsYOurWeight < 163){
          if(whatIsYOurWeight == Math.ceil(66*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(67*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-48~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(68*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-48~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(69*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-80%, Correct_Size_Second-48~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(70*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-73%, Correct_Size_Second-48~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(71*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-48~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(72*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-48~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(73*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 214 && whatIsYOurWeight < 181){
          if(whatIsYOurWeight == Math.ceil(74*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-46~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(75*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-46~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(76*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-46~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(77*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-80%, Correct_Size_Second-46~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(78*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-73%, Correct_Size_Second-50~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(79*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(80*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-50~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(81*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 179 && whatIsYOurWeight < 196){
          if(whatIsYOurWeight == Math.ceil(82*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(83*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-48~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(84*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-48~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(85*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(86*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(87*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(88*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 194 && whatIsYOurWeight < 209){
          if(whatIsYOurWeight == Math.ceil(89*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(90*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(91*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-80%, Correct_Size_Second-50~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(92*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-73%, Correct_Size_Second-54~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(93*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-54~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(94*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-54~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 207 && whatIsYOurWeight < 225){
          if(whatIsYOurWeight == Math.ceil(95*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(96*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(97*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(98*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(99*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(100*2.205)) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(101*2.205)) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }

      }
    }

    //  If Kg
    if(!jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-WIYW").is(":checked")){
      if(jQuery.trim(whatIsYOurWeight_Unit) == "kg"){
        console.log("whatIsYOurWeight_Unit kg"+whatIsYOurWeight_Unit);
        jQuery("#measure_box_2").show();
        //alert("under unit " + whatIsYOurWeight_Unit);
        //             if (whatIsYOurWeight > 65){

        if(whatIsYOurWeight > 65 && whatIsYOurWeight < 74){
          jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
          if(whatIsYOurWeight == 66) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-44~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 67) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-44~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 68) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-44~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 69) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-80%, Correct_Size_Second-44~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 70) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-73%, Correct_Size_Second-44~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 71) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-44~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 72) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-44~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 73) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-44~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 73 && whatIsYOurWeight < 82){
          jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
          if(whatIsYOurWeight == 74) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-46~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 75) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-46~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 76) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-46~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 77) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-80%, Correct_Size_Second-46~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 78) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-73%, Correct_Size_Second-50~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 79) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 80) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-50~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 81) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 81 && whatIsYOurWeight < 89){
          jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
          if(whatIsYOurWeight == 82) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 83) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-48~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 84) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-48~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 85) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 86) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 87) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 88) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 88 && whatIsYOurWeight < 95){
          jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
          if(whatIsYOurWeight == 89) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 90) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 91) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-80%, Correct_Size_Second-50~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 92) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-73%, Correct_Size_Second-54~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 93) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-54~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 94) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-54~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 94 && whatIsYOurWeight < 102){
          jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
          if(whatIsYOurWeight == 95) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 96) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 97) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 98) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 99) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 100){ Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 101){ Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight < 66 || whatIsYOurWeight > 102){
          Cookies.set('Popup_Second_Output', "null");
          jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled'); 
        }
      }
    }
  });
  /*================================================================
                                        END BASED ON WEIGHT
       ================================================================*/

  /*================================================================
                                        START BASED ON BELLY SHAPE
       ================================================================*/
  jQuery(document).on("click", ".Belly-container", function(){
    var SkinnySmaller0;
    var SkinnySmaller00;
    var SkinnySmaller1;
    var SkinnySmaller11;
    var NormalMedium0;
    var NormalMedium00;
    var NormalMedium1;
    var NormalMedium11;
    var RounderLarger0;
    var RounderLarger00;
    var RounderLarger1;
    var RounderLarger11;

    var bellyTypeBS = jQuery(this).find("input.checkbox-BS").attr("belly-type");
    var Popup_First_Output_0 = Cookies.get("Popup_First_Output").split("-");
    console.log('COOKIES----- Popup_First_Output'+Popup_First_Output_0);
    var Popup_First_Output_Main = Popup_First_Output_0[0];

    var Popup_Second_Output_0 = Cookies.get("Popup_Second_Output").split(",");

    var Prob_Size_All_First    = Popup_Second_Output_0[0].split("~");
    var Prob_Size_All_First0   = Prob_Size_All_First[0].split("-");
    var Prob_Size_All_First0_0 = Prob_Size_All_First0[0];
    var Prob_Size_All_First0_1_final = Prob_Size_All_First0[1]; 
    var Prob_Size_All_First0_1 = parseInt(Prob_Size_All_First0_1_final); // correct size first

    console.log(' Prob_Size_All_First[1]:- '+Prob_Size_All_First[1]);
    if(typeof Prob_Size_All_First[1] == 'undefined'){
      Cookies.set('Popup_Third_Output', "null"); 
    }
    var Prob_Size_All_First1   = Prob_Size_All_First[1].split("-");
    var Prob_Size_All_First1_0 = Prob_Size_All_First1[0];
    var Prob_Size_All_First1_1 = Prob_Size_All_First1[1].split("%");
    var Prob_Size_All_First1_1per_final = Prob_Size_All_First1_1[0]; 
    var Prob_Size_All_First1_1per = parseInt(Prob_Size_All_First1_1per_final); // correct probability first

    var Prob_Size_All_Second  = Popup_Second_Output_0[1].split("~");
    var Prob_Size_All_Second0 = Prob_Size_All_Second[0].split("-");
    var Prob_Size_All_Second0_0 = Prob_Size_All_Second0[0];
    var Prob_Size_All_Second0_1_final = Prob_Size_All_Second0[1]; 
    var Prob_Size_All_Second0_1 = parseInt(Prob_Size_All_Second0_1_final); // correct size second

    var Prob_Size_All_Second1 = Prob_Size_All_Second[1].split("-");
    var Prob_Size_All_Second1_0 = Prob_Size_All_Second1[0];
    var Prob_Size_All_Second1_1 = Prob_Size_All_Second1[1].split("%");
    var Prob_Size_All_Second1_1per_final = Prob_Size_All_Second1_1[0]; 
    var Prob_Size_All_Second1_1per = parseInt(Prob_Size_All_Second1_1per_final); // correct probability second


    //alert(Prob_Size_All_First0_1+" - "+Prob_Size_All_First1_1per+" - "+Prob_Size_All_Second0_1+" - "+Prob_Size_All_Second1_1per+"");

    var bellyType = jQuery(this).find("input").attr("belly-type");
    if(bellyType=="Skinny"){
      if(Prob_Size_All_First0_1<Prob_Size_All_Second0_1){
        var SkinnySmaller0 = parseInt(Prob_Size_All_First1_1per)+7;
        var SkinnySmaller00 = parseInt(Prob_Size_All_Second1_1per)-7;
        console.log('am 1 ');
        if(Prob_Size_All_First0_1<Prob_Size_All_Second0_1){
          var SkinnySmallerSize0 = parseInt(Prob_Size_All_First0_1)+0; //2
          var SkinnySmallerSize1 = parseInt(Prob_Size_All_Second0_1)-0; //2
          if(isNaN(SkinnySmaller00) || SkinnySmaller00 < 1){
            console.log('am 2 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0+"~Prob_True_First-"+SkinnySmaller0+"%, Correct_Size_Second-"+SkinnySmallerSize1+"~Prob_True_Second-"+"00"+"%"); 
          }else{
            console.log('am 3 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0+"~Prob_True_First-"+SkinnySmaller0+"%, Correct_Size_Second-"+SkinnySmallerSize1+"~Prob_True_Second-"+SkinnySmaller00+"%");
          }
        }
        if(Prob_Size_All_First0_1>Prob_Size_All_Second0_1){
          var SkinnySmallerSize00 = parseInt(Prob_Size_All_First0_1)-0; //2
          var SkinnySmallerSize11 = parseInt(Prob_Size_All_Second0_1)+0; //2
          if(isNaN(SkinnySmaller00) || SkinnySmaller00 < 1){
            console.log('am 4 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize00+"~Prob_True_First-"+SkinnySmaller0+"%, Correct_Size_Second-"+SkinnySmallerSize11+"~Prob_True_Second-"+"00"+"%");
          }else{
            console.log('am 5 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize00+"~Prob_True_First-"+SkinnySmaller0+"%, Correct_Size_Second-"+SkinnySmallerSize11+"~Prob_True_Second-"+SkinnySmaller00+"%");
          }
        }
      } 
      if(Prob_Size_All_First0_1>Prob_Size_All_Second0_1){
        var SkinnySmaller1 = parseInt(Prob_Size_All_First1_1per)-7;
        var SkinnySmaller11 = parseInt(Prob_Size_All_Second1_1per)+7;
        console.log('am 6 ');
        if(Prob_Size_All_First0_1<Prob_Size_All_Second0_1){
          var SkinnySmallerSize0_a = parseInt(Prob_Size_All_First0_1)+0; //2
          var SkinnySmallerSize1_a = parseInt(Prob_Size_All_Second0_1)-0; //2
          if(isNaN(SkinnySmaller11) || SkinnySmaller11 < 1){
            console.log('am 7 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0_a+"~Prob_True_First-"+SkinnySmaller1+"%, Correct_Size_Second-"+SkinnySmallerSize1_a+"~Prob_True_Second-"+"00"+"%");
          }else{ 
            console.log('am 8 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0_a+"~Prob_True_First-"+SkinnySmaller1+"%, Correct_Size_Second-"+SkinnySmallerSize1_a+"~Prob_True_Second-"+SkinnySmaller11+"%");
          }
        }
        if(Prob_Size_All_First0_1>Prob_Size_All_Second0_1){
          var SkinnySmallerSize0_a = parseInt(Prob_Size_All_First0_1)-0; //2
          var SkinnySmallerSize11_a = parseInt(Prob_Size_All_Second0_1)+0; //2
          if(isNaN(SkinnySmaller11) || SkinnySmaller11 < 1){
            console.log('am 9 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0_a+"~Prob_True_First-"+SkinnySmaller1+"%, Correct_Size_Second-"+SkinnySmallerSize11_a+"~Prob_True_Second-"+"00"+"%");
          }else{ 
            console.log('am 10 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0_a+"~Prob_True_First-"+SkinnySmaller1+"%, Correct_Size_Second-"+SkinnySmallerSize11_a+"~Prob_True_Second-"+SkinnySmaller11+"%");
          }
        }
      }
    }


    if(bellyType=="Normal"){
      console.log('am 11 ');
      Cookies.set('Popup_Third_Output', "Correct_Size_First-"+Prob_Size_All_First0_1+"~Prob_True_First-"+Prob_Size_All_First1_1per+"%, Correct_Size_Second-"+Prob_Size_All_Second0_1+"~Prob_True_Second-"+Prob_Size_All_Second1_1per+"%");
    }


    if(bellyType=="Rounder"){
      console.log('Prob_Size_All_First0_1:-----'+Prob_Size_All_First0_1+' Prob_Size_All_Second0_1:----'+Prob_Size_All_Second0_1);
      if(Prob_Size_All_First0_1<Prob_Size_All_Second0_1){
        var RounderLarger0 = parseInt(Prob_Size_All_First1_1per)-9;
        var RounderLarger00 = parseInt(Prob_Size_All_Second1_1per)+9;
        console.log('am 12 /Prob_Size_All_First1_1per:-'+Prob_Size_All_First1_1per+' /\ Prob_Size_All_Second1_1per'+Prob_Size_All_Second1_1per);
        if(Prob_Size_All_First0_1<Prob_Size_All_Second0_1){
          var SkinnySmallerSize0 = parseInt(Prob_Size_All_First0_1)+0;  //2
          var SkinnySmallerSize1 = parseInt(Prob_Size_All_Second0_1)-0;  //2
          if(isNaN(RounderLarger00) || RounderLarger00 < 1){
            console.log('am 13 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0+"~Prob_True_First-"+RounderLarger0+"%, Correct_Size_Second-"+SkinnySmallerSize1+"~Prob_True_Second-"+"00"+"%");
          }else{
            console.log('am 14 /RounderLarger0:'+RounderLarger0+' /\ RounderLarger00'+RounderLarger00);
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0+"~Prob_True_First-"+RounderLarger0+"%, Correct_Size_Second-"+SkinnySmallerSize1+"~Prob_True_Second-"+RounderLarger00+"%");
          }
        }
        if(Prob_Size_All_First0_1>Prob_Size_All_Second0_1){
          var SkinnySmallerSize00 = parseInt(Prob_Size_All_First0_1)-0;  //2
          var SkinnySmallerSize11 = parseInt(Prob_Size_All_Second0_1)+0;  //2
          if(isNaN(RounderLarger00) || RounderLarger00 < 1){
            console.log('am 15 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize00+"~Prob_True_First-"+RounderLarger0+"%, Correct_Size_Second-"+SkinnySmallerSize11+"~Prob_True_Second-"+"00"+"%");
          }else{
            console.log('am 16 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize00+"~Prob_True_First-"+RounderLarger0+"%, Correct_Size_Second-"+SkinnySmallerSize11+"~Prob_True_Second-"+RounderLarger00+"%");
          }
        }
      } 
      if(Prob_Size_All_First0_1>Prob_Size_All_Second0_1){
        var RounderLarger1 = parseInt(Prob_Size_All_First1_1per)+9;
        var RounderLarger11 = parseInt(Prob_Size_All_Second1_1per)-9;
        console.log('am 17 ');
        if(Prob_Size_All_First0_1<Prob_Size_All_Second0_1){
          var SkinnySmallerSize0 = parseInt(Prob_Size_All_First0_1)+0;  //2
          var SkinnySmallerSize1 = parseInt(Prob_Size_All_Second0_1)-0;  //2
          if(isNaN(RounderLarger11) || RounderLarger11 < 1){
            console.log('am 18 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0+"~Prob_True_First-"+RounderLarger1+"%, Correct_Size_Second-"+SkinnySmallerSize1+"~Prob_True_Second-"+"00"+"%");
          }else{
            console.log('am 19 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize0+"~Prob_True_First-"+RounderLarger1+"%, Correct_Size_Second-"+SkinnySmallerSize1+"~Prob_True_Second-"+RounderLarger11+"%");
          }
        }
        if(Prob_Size_All_First0_1>Prob_Size_All_Second0_1){
          var SkinnySmallerSize00 = parseInt(Prob_Size_All_First0_1)-0;  //2
          var SkinnySmallerSize11 = parseInt(Prob_Size_All_Second0_1)+0;  //2
          if(isNaN(RounderLarger11) || RounderLarger11 < 1){
            console.log('am 20 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize00+"~Prob_True_First-"+RounderLarger1+"%, Correct_Size_Second-"+SkinnySmallerSize11+"~Prob_True_Second-"+"00"+"%");
          }else{
            console.log('am 21 ');
            Cookies.set('Popup_Third_Output', "Correct_Size_First-"+SkinnySmallerSize00+"~Prob_True_First-"+RounderLarger1+"%, Correct_Size_Second-"+SkinnySmallerSize11+"~Prob_True_Second-"+RounderLarger11+"%");
          }
        }
      }
    }

  }); 
  /*================================================================
                                        END BASED ON BELLY SHAPE
        ================================================================*/ 

  /*================================================================
                                        END BASED ON SHOULDER WIDTH
        ================================================================*/ 

  jQuery(document).on("click", ".Shoulder-width-container", function(){
    var Popup_Third_Output_Main = Cookies.get("Popup_Third_Output");
    //console.log(Popup_Third_Output_Main);
    var Main_Cookie_Split       = Popup_Third_Output_Main.split(","); // main cookies split

    var Main_Cookie_Split_First          = Main_Cookie_Split[0];               // split first part
    var Main_Cookie_Split_First_Sub      = Main_Cookie_Split_First.split("~"); // main sub split

    var Main_Cookie_Split_First_Sub_First         = Main_Cookie_Split_First_Sub[0].split("-");     // main sub split First
    var Main_Cookie_Split_First_Sub_First_0       = Main_Cookie_Split_First_Sub_First[0];          // main sub split First 0 
    var Main_Cookie_Split_First_Sub_First_1       = Main_Cookie_Split_First_Sub_First[1];          // main sub split First 1
    var Main_Cookie_Split_First_Sub_First_1__Main = parseInt(Main_Cookie_Split_First_Sub_First_1); // main sub split First 1   Size

    console.log('Main_Cookie_Split_First_Sub[1]:- '+Main_Cookie_Split_First_Sub[1]);
    if(typeof Main_Cookie_Split_First_Sub[1] == 'undefined'){
      Cookies.set('Popup_Fourth_Output', "null");
    }
    var Main_Cookie_Split_First_Sub_Second        = Main_Cookie_Split_First_Sub[1].split("-");     // main sub split Second
    var Main_Cookie_Split_First_Sub_Second_0      = Main_Cookie_Split_First_Sub_Second[0];         // main sub split Second 0
    var Main_Cookie_Split_First_Sub_Second_1      = Main_Cookie_Split_First_Sub_Second[1];         // main sub split Second 1
    var Main_Cookie_Split_First_Sub_Second_1__Main= parseInt(Main_Cookie_Split_First_Sub_Second_1);// main sub split Second 1 Probability

    var Main_Cookie_Split_Second          = Main_Cookie_Split[1];                 // split second part
    var Main_Cookie_Split_Second_Sub      = Main_Cookie_Split_Second.split("~");  // main sub split

    var Main_Cookie_Split_Second_Sub_Second         = Main_Cookie_Split_Second_Sub[0].split("-");         // main sub split First
    var Main_Cookie_Split_Second_Sub_Second_0       = Main_Cookie_Split_Second_Sub_Second[0];             // main sub split First 0 
    var Main_Cookie_Split_Second_Sub_Second_1       = Main_Cookie_Split_Second_Sub_Second[1];             // main sub split First 1
    var Main_Cookie_Split_Second_Sub_Second_1__Main = parseInt(Main_Cookie_Split_Second_Sub_Second_1);    // main sub split First 1 Size
    var Main_Cookie_Split_Second_Sub_Seconda         = Main_Cookie_Split_Second_Sub[1].split("-")      ;  // main sub split Second
    var Main_Cookie_Split_Second_Sub_Seconda_0       = Main_Cookie_Split_Second_Sub_Seconda[0];           // main sub split Second 0
    var Main_Cookie_Split_Second_Sub_Seconda_1       = Main_Cookie_Split_Second_Sub_Seconda[1];           // main sub split Second 1
    var Main_Cookie_Split_Second_Sub_Seconda_1__Main = parseInt(Main_Cookie_Split_Second_Sub_Seconda_1);  // main sub split Second 1 Probability

    //console.log(Main_Cookie_Split_First_Sub_First_1__Main+" - "+Main_Cookie_Split_First_Sub_Second_1__Main+" - "+Main_Cookie_Split_Second_Sub_Second_1__Main+" - "+Main_Cookie_Split_Second_Sub_Seconda_1__Main);
    var shoulderType = jQuery(this).find("input.checkbox-SW").attr("shoulder-type");
    if(shoulderType=="Narrow"){
      if(Main_Cookie_Split_First_Sub_First_1__Main<Main_Cookie_Split_Second_Sub_Second_1__Main){
        var SkinnySmaller0Sh = Main_Cookie_Split_First_Sub_Second_1__Main+16;
        var SkinnySmaller00Sh = Main_Cookie_Split_Second_Sub_Seconda_1__Main-16;
        console.log("Before Narrow 1 "+Main_Cookie_Split_First_Sub_Second_1__Main+" & "+Main_Cookie_Split_Second_Sub_Seconda_1__Main);
        console.log("Narrow 1 (+) "+SkinnySmaller0Sh+" & (-) "+SkinnySmaller00Sh);
        if(Main_Cookie_Split_First_Sub_First_1__Main<Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize0Sh = Main_Cookie_Split_First_Sub_First_1__Main+0;  //2
          var SkinnySmallerSize1Sh = Main_Cookie_Split_Second_Sub_Second_1__Main-0;  //2
          if(isNaN(SkinnySmaller00Sh) || SkinnySmaller00Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0Sh+"~Prob_True_First-"+SkinnySmaller0Sh+"%, Correct_Size_Second-"+SkinnySmallerSize1Sh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0Sh+"~Prob_True_First-"+SkinnySmaller0Sh+"%, Correct_Size_Second-"+SkinnySmallerSize1Sh+"~Prob_True_Second-"+SkinnySmaller00Sh+"%");
          }
        }
        if(Main_Cookie_Split_First_Sub_First_1__Main>Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize00Sh = Main_Cookie_Split_First_Sub_First_1__Main-0;  //2
          var SkinnySmallerSize11Sh = Main_Cookie_Split_Second_Sub_Second_1__Main+0;  //2
          if(isNaN(SkinnySmaller00Sh) || SkinnySmaller00Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize00Sh+"~Prob_True_First-"+SkinnySmaller0Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11Sh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize00Sh+"~Prob_True_First-"+SkinnySmaller0Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11Sh+"~Prob_True_Second-"+SkinnySmaller00Sh+"%");
          }
        }
      }
      if(Main_Cookie_Split_First_Sub_First_1__Main>Main_Cookie_Split_Second_Sub_Second_1__Main){
        var SkinnySmaller1Sh = Main_Cookie_Split_Second_Sub_Seconda_1__Main+16;
        var SkinnySmaller11Sh = Main_Cookie_Split_First_Sub_Second_1__Main-16;
        console.log("Before Narrow 2 "+Main_Cookie_Split_First_Sub_Second_1__Main+" & "+Main_Cookie_Split_Second_Sub_Seconda_1__Main);
        console.log("Narrow 2 (+) "+SkinnySmaller1Sh+" & (-) "+SkinnySmaller11Sh);
        if(Main_Cookie_Split_First_Sub_First_1__Main<Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize0_aSh = Main_Cookie_Split_First_Sub_First_1__Main+0;  //2
          var SkinnySmallerSize1_aSh = Main_Cookie_Split_Second_Sub_Second_1__Main-0;  //2
          if(isNaN(SkinnySmaller1Sh) || SkinnySmaller1Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0_aSh+"~Prob_True_First-"+SkinnySmaller11Sh+"%, Correct_Size_Second-"+SkinnySmallerSize1_aSh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0_aSh+"~Prob_True_First-"+SkinnySmaller11Sh+"%, Correct_Size_Second-"+SkinnySmallerSize1_aSh+"~Prob_True_Second-"+SkinnySmaller1Sh+"%");
          }
        }
        if(Main_Cookie_Split_First_Sub_First_1__Main>Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize0_aSh = Main_Cookie_Split_First_Sub_First_1__Main-0;  //2
          var SkinnySmallerSize11_aSh = Main_Cookie_Split_Second_Sub_Second_1__Main+0;  //2
          if(isNaN(SkinnySmaller1Sh) || SkinnySmaller1Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0_aSh+"~Prob_True_First-"+SkinnySmaller11Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11_aSh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0_aSh+"~Prob_True_First-"+SkinnySmaller11Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11_aSh+"~Prob_True_Second-"+SkinnySmaller1Sh+"%");
          }
        }
      }
    }
    if(shoulderType=="Normal"){
      Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+Main_Cookie_Split_First_Sub_First_1__Main+"~Prob_True_First-"+Main_Cookie_Split_First_Sub_Second_1__Main+"%, Correct_Size_Second-"+Main_Cookie_Split_Second_Sub_Second_1__Main+"~Prob_True_Second-"+Main_Cookie_Split_Second_Sub_Seconda_1__Main+"%");
    }
    if(shoulderType=="Wide"){
      if(Main_Cookie_Split_First_Sub_First_1__Main<Main_Cookie_Split_Second_Sub_Second_1__Main){
        var SkinnySmaller0Sh = Main_Cookie_Split_Second_Sub_Seconda_1__Main+19;
        var SkinnySmaller00Sh = Main_Cookie_Split_First_Sub_Second_1__Main-19;
        console.log("Before Wide 1 "+Main_Cookie_Split_First_Sub_Second_1__Main+" & "+Main_Cookie_Split_Second_Sub_Seconda_1__Main);
        console.log("Wide 1 (+19) "+SkinnySmaller0Sh+" & (-19) "+SkinnySmaller00Sh);
        if(Main_Cookie_Split_First_Sub_First_1__Main<Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize0Sh = Main_Cookie_Split_Second_Sub_Second_1__Main+0;   //2
          var SkinnySmallerSize1Sh = Main_Cookie_Split_First_Sub_First_1__Main-0;   //2
          if(isNaN(SkinnySmaller0Sh) || SkinnySmaller0Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize1Sh+"~Prob_True_First-"+SkinnySmaller00Sh+"%, Correct_Size_Second-"+SkinnySmallerSize0Sh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize1Sh+"~Prob_True_First-"+SkinnySmaller00Sh+"%, Correct_Size_Second-"+SkinnySmallerSize0Sh+"~Prob_True_Second-"+SkinnySmaller0Sh+"%");
          }
        }
        if(Main_Cookie_Split_First_Sub_First_1__Main>Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize00Sh = Main_Cookie_Split_First_Sub_First_1__Main-0;   //2
          var SkinnySmallerSize11Sh = Main_Cookie_Split_Second_Sub_Second_1__Main+0;   //2
          if(isNaN(SkinnySmaller0Sh) || SkinnySmaller0Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize00Sh+"~Prob_True_First-"+SkinnySmaller00Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11Sh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize00Sh+"~Prob_True_First-"+SkinnySmaller00Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11Sh+"~Prob_True_Second-"+SkinnySmaller0Sh+"%");
          }
        }
      } 
      if(Main_Cookie_Split_First_Sub_First_1__Main>Main_Cookie_Split_Second_Sub_Second_1__Main){
        var SkinnySmaller1Sh = Main_Cookie_Split_First_Sub_Second_1__Main+19;
        var SkinnySmaller11Sh = Main_Cookie_Split_Second_Sub_Seconda_1__Main-19;
        console.log("Before Wide 2 "+Main_Cookie_Split_First_Sub_Second_1__Main+" & "+Main_Cookie_Split_Second_Sub_Seconda_1__Main);
        console.log("Wide 2 (+19) "+SkinnySmaller1Sh+" & (-19) "+SkinnySmaller11Sh);
        if(Main_Cookie_Split_First_Sub_First_1__Main<Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize0_aSh = Main_Cookie_Split_Second_Sub_Second_1__Main+0;   //2
          var SkinnySmallerSize1_aSh = Main_Cookie_Split_First_Sub_First_1__Main-0;   //2
          if(isNaN(SkinnySmaller11Sh) || SkinnySmaller11Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize1_aSh+"~Prob_True_First-"+SkinnySmaller1Sh+"%, Correct_Size_Second-"+SkinnySmallerSize0_aSh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize1_aSh+"~Prob_True_First-"+SkinnySmaller1Sh+"%, Correct_Size_Second-"+SkinnySmallerSize0_aSh+"~Prob_True_Second-"+SkinnySmaller11Sh+"%");
          }
        }
        if(Main_Cookie_Split_First_Sub_First_1__Main>Main_Cookie_Split_Second_Sub_Second_1__Main){
          var SkinnySmallerSize0_aSh = Main_Cookie_Split_First_Sub_First_1__Main+0;   //2
          var SkinnySmallerSize11_aSh = Main_Cookie_Split_Second_Sub_Second_1__Main-0;   //2
          if(isNaN(SkinnySmaller11Sh) || SkinnySmaller11Sh < 1){
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0_aSh+"~Prob_True_First-"+SkinnySmaller1Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11_aSh+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fourth_Output', "Correct_Size_First-"+SkinnySmallerSize0_aSh+"~Prob_True_First-"+SkinnySmaller1Sh+"%, Correct_Size_Second-"+SkinnySmallerSize11_aSh+"~Prob_True_Second-"+SkinnySmaller11Sh+"%");
          }
        }
      }   
    }
  }); 

  /*================================================================
                        END BASED ON SHOULDER WIDTH
        ================================================================*/ 

  /*================================================================
                       START BASED ON HOW OLD ARE YOU
        ================================================================*/
  jQuery(document).on("keyup", ".input-type-HORU", function(){
    var howOldAreYou = jQuery(this).val();
    var howOldAreYouInt = parseInt(howOldAreYou);
    var Popup_Fourth_Output_Main = Cookies.get("Popup_Fourth_Output");
    // Correct_Size_First-46~Prob_True_First-36%, Correct_Size_Second-44~Prob_True_Second-64%
    //alert("main cookir get "+ Popup_Fourth_Output_Main);
    var Main_T_Cookie_Split = Popup_Fourth_Output_Main.split(",");

    var Main_T_Cookie_Split__0_a = Main_T_Cookie_Split[0];
    var Main_T_Cookie_Split__1_a = Main_T_Cookie_Split[1];

    var Main_T_Cookie_Split_First = Main_T_Cookie_Split__0_a.split("~");
    var Main_T_Cookie_Split_First0 = Main_T_Cookie_Split_First[0];
    var Main_T_Cookie_Split_First1 = Main_T_Cookie_Split_First[1];

    var Main_T_Cookie_Split_First_a = Main_T_Cookie_Split_First0.split("-");
    var Main_T_Cookie_Split_First_a_0 = Main_T_Cookie_Split_First_a[1];
    var Main_T_Cookie_Split_First_a_1 = parseInt(Main_T_Cookie_Split_First_a_0); // size 1
    console.log('Main_T_Cookie_Split_First1'+Main_T_Cookie_Split_First1);
    if(typeof Main_T_Cookie_Split_First1 == 'undefined'){
      if(howOldAreYouInt>15){
        console.log('Enabled how Old Are You ----> '+howOldAreYouInt)
        jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
        Cookies.set('Popup_Fifth_Output', "null"); 
      }else{
        console.log('Disabled how Old Are You ----> '+howOldAreYouInt)
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    }
    var Main_T_Cookie_Split_First_b = Main_T_Cookie_Split_First1.split("-");
    var Main_T_Cookie_Split_First_b_0 = Main_T_Cookie_Split_First_b[1]; 
    var Main_T_Cookie_Split_First_b_1 = parseInt(Main_T_Cookie_Split_First_b_0); // probability 1


    var Main_T_Cookie_Split_Second = Main_T_Cookie_Split__1_a.split("~");
    var Main_T_Cookie_Split_Second0 = Main_T_Cookie_Split_Second[0];
    var Main_T_Cookie_Split_Second1 = Main_T_Cookie_Split_Second[1];

    var Main_T_Cookie_Split_Second_a = Main_T_Cookie_Split_Second0.split("-");
    var Main_T_Cookie_Split_Second_a_0 = Main_T_Cookie_Split_Second_a[1];
    var Main_T_Cookie_Split_Second_a_1 = parseInt(Main_T_Cookie_Split_Second_a_0); // size 2

    var Main_T_Cookie_Split_Second_b = Main_T_Cookie_Split_Second1.split("-");
    var Main_T_Cookie_Split_Second_b_0 = Main_T_Cookie_Split_Second_b[1];
    var Main_T_Cookie_Split_Second_b_1 = parseInt(Main_T_Cookie_Split_Second_b_0); // probability 2

    //alert(Main_T_Cookie_Split_First_a_1 + " & " + Main_T_Cookie_Split_First_b_1 + " & " + Main_T_Cookie_Split_Second_a_1 + " & " +Main_T_Cookie_Split_Second_b_1);
    if(howOldAreYouInt>15){
      console.log('Enabled how Old Are You ----> '+howOldAreYouInt)
      jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
    }else{
      console.log('Disabled how Old Are You ----> '+howOldAreYouInt)
      jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
    }
    if(howOldAreYouInt<36){
      //alert("howOldAreYouInt"+ " & " +Main_T_Cookie_Split_First_b_1 + "--" + Main_T_Cookie_Split_Second_a_1);
      if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
        //alert("below thirty five first");
        var getFinalSizePlus  = Main_T_Cookie_Split_Second_b_1-5;
        var getFinalSizeMinus = Main_T_Cookie_Split_First_b_1+5;
        if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0;  //2
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;  //2
          if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizePlus+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0;  //2
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0;  //2
          if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizePlus+"%");
          }
        }
      }
      if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
        //alert("below thirty five second");
        //alert(Main_T_Cookie_Split_First_b_1);
        //alert(Main_T_Cookie_Split_Second_b_1);
        var getFinalSizePlus  = Main_T_Cookie_Split_First_b_1-5;
        var getFinalSizeMinus = Main_T_Cookie_Split_Second_b_1+5;
        //alert(getFinalSizePlus);
        //alert(getFinalSizeMinus);
        if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0; //2
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;  //2
          if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0; //2
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0; //2
          if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
          }
        }
      }
    }
    if(howOldAreYouInt>35){
      //alert("howOldAreYouInt>36");
      //alert(Main_T_Cookie_Split_First_b_1+ " &^& " +Main_T_Cookie_Split_Second_b_1);
      if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
        //alert("above thirty five first");
        var getFinalSizePlus  = Main_T_Cookie_Split_First_b_1-5;
        var getFinalSizeMinus = Main_T_Cookie_Split_Second_b_1+5;
        console.log("howOldAreYouInt>35 1 "+Main_T_Cookie_Split_First_a_1+" & "+Main_T_Cookie_Split_Second_a_1);
        console.log("howOldAreYouInt>35 1 (+5,-5) "+getFinalSizePlus+" & (-19) "+getFinalSizeMinus);        
        if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0;  //2
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0;  //2
          if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0;  //2
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;  //2
          if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
          }
        }
      }
      if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
        var getFinalSizePlus  = Main_T_Cookie_Split_Second_b_1-5;
        var getFinalSizeMinus = Main_T_Cookie_Split_First_b_1+5;
        //console.log("howOldAreYouInt>35 1 "+Main_T_Cookie_Split_First_a_1+" & "+Main_T_Cookie_Split_Second_a_1);
        //console.log("howOldAreYouInt>35 1 (+5,-5) "+getFinalSizePlus+" & (-19) "+getFinalSizeMinus); 
        //Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizePlus+"%");
        if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0;
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0;
          if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizePlus+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
          var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0;
          var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;
          if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizePlus+"%");
          }
        }
      }   
    }

  });
  /*================================================================
                          END BASED ON HOW OLD ARE YOU
        ================================================================*/

  /*================================================================
                         START BASED ON FIT PREFERENCE
        ================================================================*/
  jQuery(document).on("click", ".c-range-main-input-FP", function(){
    var grand_le_mar_fp_val = jQuery(this).val();
    var c_Range_Main_Input_FP = jQuery(this).val();
    var c_Range_Main_Input__Attr_FP = jQuery.trim(jQuery(this).attr("fit-pref"));
    //console.log(c_Range_Main_Input_FP+" & "+c_Range_Main_Input__Attr_FP);
    var Popup_Fifth_Output_Main_Final = Cookies.get("Popup_Fifth_Output");
    console.log('Popup_Fifth_Output_Main_Final-'+Popup_Fifth_Output_Main_Final);
    var Main_T_Cookie_Split_Final = Popup_Fifth_Output_Main_Final.split(",");

    var Main_T_Cookie_Split__0_a_Final = Main_T_Cookie_Split_Final[0];
    var Main_T_Cookie_Split__1_a_Final = Main_T_Cookie_Split_Final[1];

    var Main_T_Cookie_Split_First_Final = Main_T_Cookie_Split__0_a_Final.split("~");
    var Main_T_Cookie_Split_First0_Final = Main_T_Cookie_Split_First_Final[0];
    var Main_T_Cookie_Split_First1_Final = Main_T_Cookie_Split_First_Final[1];

    console.log('Main_T_Cookie_Split_First0_Final--------------------------'+Main_T_Cookie_Split_First0_Final);
    var Main_T_Cookie_Split_First_a_Final = Main_T_Cookie_Split_First0_Final.split("-");
    var Main_T_Cookie_Split_First_a_0_Final = Main_T_Cookie_Split_First_a_Final[1];
    var Main_T_Cookie_Split_First_a_1_Final = parseInt(Main_T_Cookie_Split_First_a_0_Final); // size 1

    console.log('Main_T_Cookie_Split_First1_Final--------------------------'+Main_T_Cookie_Split_First1_Final);
    if(typeof Main_T_Cookie_Split_First1_Final == 'undefined'){
      console.log('Main_T_Cookie_Split_First1_Final <----> '+Main_T_Cookie_Split_First1_Final);
      Cookies.set('Popup_Sixth_Output', "null");
      if(jQuery(".steps-HTAY").find("span.step-5.round-all").hasClass('active')){
        jQuery(".steps-HTAY").find("span.step-6.round-all").click();
        jQuery(".steps-HTAY").find("span.step-6.round-all").trigger("click");
      }

      jQuery('.FitFinder-result_S-0 span.compare-msg,p.main-heading-HTAY,.FitFinder-result_R-0,span.compare-msg').hide();
      jQuery('.FitFinder-result_S-0 ').addClass("comapre_result");
    }
    var Main_T_Cookie_Split_First_b_Final = Main_T_Cookie_Split_First1_Final.split("-");
    var Main_T_Cookie_Split_First_b_0_Final = Main_T_Cookie_Split_First_b_Final[1]; 
    var Main_T_Cookie_Split_First_b_1_Final = parseInt(Main_T_Cookie_Split_First_b_0_Final); // probability 1

    console.log('Main_T_Cookie_Split__1_a_Final--------------------------'+Main_T_Cookie_Split__1_a_Final);
    var Main_T_Cookie_Split_Second_Final = Main_T_Cookie_Split__1_a_Final.split("~");
    var Main_T_Cookie_Split_Second0_Final = Main_T_Cookie_Split_Second_Final[0];
    var Main_T_Cookie_Split_Second1_Final = Main_T_Cookie_Split_Second_Final[1];

    var Main_T_Cookie_Split_Second_a_Final = Main_T_Cookie_Split_Second0_Final.split("-");
    var Main_T_Cookie_Split_Second_a_0_Final = Main_T_Cookie_Split_Second_a_Final[1];
    var Main_T_Cookie_Split_Second_a_1_Final = parseInt(Main_T_Cookie_Split_Second_a_0_Final); // size 2

    var Main_T_Cookie_Split_Second_b_Final = Main_T_Cookie_Split_Second1_Final.split("-");
    var Main_T_Cookie_Split_Second_b_0_Final = Main_T_Cookie_Split_Second_b_Final[1];
    var Main_T_Cookie_Split_Second_b_1_Final = parseInt(Main_T_Cookie_Split_Second_b_0_Final); // probability 2

    console.log(c_Range_Main_Input__Attr_FP+' ******** '+Main_T_Cookie_Split_First_a_1_Final+' ********* '+Main_T_Cookie_Split_Second_a_1_Final);
    if(c_Range_Main_Input__Attr_FP=="TIGHT"){
      // probabilty based first one
      if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
        var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final+16;
        var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final-16;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
      }
      // probabilty based second one
      if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
        var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final+16;
        var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final-16;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
      }
    }

    if(c_Range_Main_Input__Attr_FP=="LITTLE TIGHT"){
      // probabilty based first one
      if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
        var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final+11;
        var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final-11;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
          } else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
      }
      // probabilty based second one
      if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
        var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final+11;
        var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final-11;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
      }
    }

    if(c_Range_Main_Input__Attr_FP=="NORMAL" || c_Range_Main_Input__Attr_FP == "" || c_Range_Main_Input__Attr_FP == " " || grand_le_mar_fp_val == 3){
      //alert("grand_le_mar_fp_val "+grand_le_mar_fp_val);
      //alert(Main_T_Cookie_Split_First_a_1_Final+ " -- "+ Main_T_Cookie_Split_First_b_1_Final + " -- "+ Main_T_Cookie_Split_Second_a_1_Final + " -- "+ Main_T_Cookie_Split_Second_b_1_Final);
      Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+Main_T_Cookie_Split_First_a_1_Final+"~Prob_True_First-"+Main_T_Cookie_Split_First_b_1_Final+"%, Correct_Size_Second-"+Main_T_Cookie_Split_Second_a_1_Final+"~Prob_True_Second-"+Main_T_Cookie_Split_Second_b_1_Final+"%");
    }

    if(c_Range_Main_Input__Attr_FP=="LITTLE LOOSE"){
      // probabilty based first one
      if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
        //alert("first type of alert");
        var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final-11;
        var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final+11;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLargerSize+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLargerSize+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
      }
      // probabilty based second one
      if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
        //alert("second type of alert");
        var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final-11;
        var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final+11;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
      }
    }

    if(c_Range_Main_Input__Attr_FP=="LOOSE"){
      // probabilty based first one
      if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
        var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final-16;
        var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final+16;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
          }
        }
      }
      // probabilty based second one
      if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
        var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final-16;
        var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final+16;
        if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
        if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
          var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
          var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
          if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
          }else{
            Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
          }
        }
      }
    }
  });
  /*================================================================
                         END BASED ON FIT PREFERENCE
        ================================================================*/ 


  /*================================================================
                         START BASED ON PROCESSING BAR
        ================================================================*/ 
  jQuery(document).on("click", ".c-range-main-input-FP", function(){
    var cookie_six_output = Cookies.get("Popup_Sixth_Output");
    var split_six_cookie = cookie_six_output.split(",");
    //alert("split_six_cookie "+split_six_cookie);

    var six_cookie_first = split_six_cookie[0].split("~"); // sixth cookies part first
    var six_cookie_first_split = six_cookie_first[0].split("-"); // sixth cookies part first split 0
    var six_cookie_second_split = six_cookie_first[1].split("-"); // sixth cookies part first split 1
    var six_cookie_first_size = parseInt(six_cookie_first_split[1]); // first size
    var six_cookie_first_prob = parseInt(six_cookie_second_split[1]); // first probability
    //alert("six_cookie_first_size "+six_cookie_first_size + "& six_cookie_first_prob " +six_cookie_first_prob);
    var six_cookie_second = split_six_cookie[1].split("~"); // sixth cookies part second
    var six_cookie_second_split0 = six_cookie_second[0].split("-"); // sixth cookies part second split 0
    var six_cookie_second_split1 = six_cookie_second[1].split("-"); // sixth cookies part second split 1
    var six_cookie_second_size = parseInt(six_cookie_second_split0[1]); // second size
    var six_cookie_second_prob = parseInt(six_cookie_second_split1[1]); // second probability

    var Popup_First_Output = Cookies.get("Popup_First_Output"); //pop up first output
    var Popup_First_Output_0 = Popup_First_Output.split("-");
    var Popup_First_Output_Size = Popup_First_Output_0[0];
    console.log("c-range-main-input-FP----" + six_cookie_first_size);

    console.log('six_cookie-------- Size:-'+six_cookie_first_size + "-" +six_cookie_first_prob + " & Size:-" +six_cookie_second_size + "-" +six_cookie_second_prob);
    //alert(six_cookie_first_prob+" & "+six_cookie_second_prob);
    if(six_cookie_first_prob==six_cookie_second_prob){
      //alert("both are equal");
      document.getElementById("random__number_a").style.width = six_cookie_first_prob+"%";document.getElementById("random__number_a").innerHTML = six_cookie_first_prob+"%";
      document.getElementById("random__number_aa").style.width = six_cookie_second_prob+"%";document.getElementById("random__number_aa").innerHTML = six_cookie_second_prob+"%";
    }
    if(six_cookie_first_prob>six_cookie_second_prob || isNaN(six_cookie_second_prob)){
      console.log("first size bigger");
      var probabilityMax = six_cookie_first_prob; // probability first (larger)
      var probabilityMin = six_cookie_second_prob; // probability first (smaller)
      // first larger
      var result_large0 = six_cookie_first_size; // US size
      var result_large1 = six_cookie_first_size+10;  // EU size
      // second smaller
      var result_large_a = six_cookie_second_size; // US size
      var result_large_aa = six_cookie_second_size+10;  // EU size
      if(Popup_First_Output_Size=="S"){
        jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").show();
        jQuery(".FitFinder-result_S-0").addClass("no_result");
        jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").hide(); jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").hide();
        jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').hide();
        document.getElementById("random__number_size").innerHTML = result_large1+" EU / "+result_large0+" - "+ Popup_First_Output_Size +" - "+" US";
        document.getElementById("random__numbera_size").innerHTML = result_large_aa+" EU / "+result_large_a+" - "+ Popup_First_Output_Size +" - "+" US";
        document.getElementById("random__number_a").style.width = probabilityMax+"%";
        document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
        document.getElementById("random__number_aa").style.width = probabilityMin+"%";
        document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
        console.log('PB 1');
      }
      if(Popup_First_Output_Size=="R"){
        if(six_cookie_first_size == 46){
          //alert("size 46");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();
          jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(six_cookie_first_prob>84){
            document.getElementById("random__number_size").innerHTML = "46"+" EU / "+ "36" + Popup_First_Output_Size +" - "+" US";
            //alert("six_cookie_second_size "+six_cookie_second_size);
            if(six_cookie_second_size == 44){
              document.getElementById("random__numbera_size").innerHTML = "48 EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 48){
              document.getElementById("random__numbera_size").innerHTML = " 48 EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_a").innerHTML = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";
            document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('PB 2');
          }
          if(six_cookie_first_prob<84){
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "46 EU / "+ "36" + Popup_First_Output_Size +" - "+" US";
              //alert("six_cookie_second_size "+six_cookie_second_size);
              if(six_cookie_second_size == 44){
                document.getElementById("random__numbera_size").innerHTML = "48"+" EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = " 48 EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 3');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              console.log(' probabilityMin '+probabilityMax+' probabilityMin '+probabilityMin)
              document.getElementById("random__number_size").innerHTML = result_large1+" EU / "+ six_cookie_first_size + Popup_First_Output_Size +" - "+" US";
              //alert("six_cookie_second_size "+six_cookie_second_size);
              if(six_cookie_second_size == 44){
                document.getElementById("random__numbera_size").innerHTML = "54 EU / "+ six_cookie_second_size + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = " 58 EU / "+ six_cookie_second_size + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";
              document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 4:->'+ probabilityMin);
            }
          }
        }
        if(six_cookie_first_size == 48){
          //alert("probabilityMax "+probabilityMax+"probabilityMin "+probabilityMin);
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();
          jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(six_cookie_first_prob>84){
            document.getElementById("random__number_size").innerHTML = "48"+" EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 46){
              document.getElementById("random__numbera_size").innerHTML = "46 EU / "+ "36" + Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "50 EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_a").innerHTML = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";
            document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('PB 5');
          }
          if(six_cookie_first_prob<84){
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "46 EU / "+ "36" + Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 46){
                document.getElementById("random__numbera_size").innerHTML = "48"+" EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "50 EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 6');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "48"+" EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 46){
                document.getElementById("random__numbera_size").innerHTML = "46 EU / "+ "36" + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "50 EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 7');
            }
          }
        }
        if(six_cookie_first_size == 50){
          //alert("+++++++++probabilityMax "+probabilityMax+"probabilityMin "+probabilityMin);
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();
          jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(six_cookie_first_prob>84){
            document.getElementById("random__number_size").innerHTML = "50 EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 48){
              document.getElementById("random__numbera_size").innerHTML = "48 EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "48 EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_a").innerHTML = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";
            document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('PB 8');
          }
          if(six_cookie_first_prob<84){
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "48 EU / "+ "" + "38" +" - "+" US";
              if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = "52 EU / "+ "42" + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "50"+" EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 9');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "52 EU / "+ "42" + Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = "48 EU / "+ "38" + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "50"+" EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 10');
            }
          }
        }
        if(six_cookie_first_size == 52){
          //alert("size 52");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(six_cookie_first_prob>84){
            document.getElementById("random__number_size").innerHTML = "52"+" EU / "+ "42" + Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "54 EU / "+ "44" + Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 54){
              document.getElementById("random__numbera_size").innerHTML = "54 EU / "+ "44" + Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_a").innerHTML = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";
            document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('PB 11');
          }
          if(six_cookie_first_prob<84){
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "50 EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = result_large1+" EU / "+ six_cookie_first_size + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 54){
                document.getElementById("random__numbera_size").innerHTML = "54 EU / "+ "44" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 12');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "52"+" EU / "+ "42" + Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "50 EU / "+ "40" + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 54){
                document.getElementById("random__numbera_size").innerHTML = "54 EU / "+ "44" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 13');
            }
          }
        }
        if(six_cookie_first_size == 54){
          //alert("size 54");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();
          jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(six_cookie_first_prob>84){
            document.getElementById("random__number_size").innerHTML = result_large1+" EU / "+ six_cookie_first_size + Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "62 EU / "+ six_cookie_second_size + Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 56){
              document.getElementById("random__numbera_size").innerHTML = "66 EU / "+ six_cookie_second_size + Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_a").innerHTML = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";
            document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('PB 14');
          }
          if(six_cookie_first_prob<84){
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "52 EU / "+ "42" + Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = result_large1+" EU / "+ six_cookie_first_size + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 56){
                document.getElementById("random__numbera_size").innerHTML = "54 EU / "+ "44" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 14');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = result_large1+" EU / "+ six_cookie_first_size + Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "52 EU / "+ "42" + Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 56){
                document.getElementById("random__numbera_size").innerHTML = "54 EU / "+ "44" + Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 15');
            }
          }
        }
        if(six_cookie_first_size != 46 && six_cookie_first_size != 48 && six_cookie_first_size != 50 && six_cookie_first_size != 52 && six_cookie_first_size != 54){
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").show();
          jQuery(".FitFinder-result_S-0").addClass("no-result");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").hide();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").hide();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').hide();
        }
      }
      // large 
      if(Popup_First_Output_Size=="L"){
        //alert("probability large 1 "+ probabilityMax+"-  -----"+Popup_First_Output_Size);
        if(six_cookie_first_size == 48){
          if(six_cookie_first_prob>84){
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "94"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 46){
              document.getElementById("random__numbera_size").innerHTML = "90 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('PB 16');
          }
          if(six_cookie_first_prob<84){
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "94"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 46){
              document.getElementById("random__numbera_size").innerHTML = "90 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "90 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 46){
                document.getElementById("random__numbera_size").innerHTML = "94"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // ----------------------------------------
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 17');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "94"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 46){
                document.getElementById("random__numbera_size").innerHTML = "90 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // ----------------------------------------
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 18');
            }
          }
        }
        if(six_cookie_first_size == 50){
          //alert("pass first if + 50");
          if(six_cookie_first_prob>84){
            //alert("pass second if + entry more then 84");
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "98"+" EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 48){
              document.getElementById("random__numbera_size").innerHTML = "94 EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('PB 19');
          }
          if(six_cookie_first_prob<84){
            //alert("pass second if + entry less then 84 - 0");
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            if(probabilityMax > 84 && probabilityMin < 16){
              //alert("pass second if + entry less then 84 - 1");
              document.getElementById("random__number_size").innerHTML = "94 EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = "98"+" EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // ---------------------------------------------
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 20');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              //alert("pass second if + entry less then 84 - 2");
              //alert("six_cookie_first_prob " + six_cookie_first_prob + "six_cookie_second_prob " + six_cookie_second_prob);
              document.getElementById("random__number_size").innerHTML = "98"+" EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = "94 EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // ---------------------------------------------
              document.getElementById("random__number_a").style.width = probabilityMax+"%";
              document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";
              document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 21');
            }
          }
        }
        if(six_cookie_first_size == 52){ 
          if(six_cookie_first_prob>84){
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "102"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 54){
              document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('PB 22');
          }
          if(six_cookie_first_prob<84){
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "102"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 54){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 23');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__numbera_size").innerHTML = "102"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 50){
                document.getElementById("random__number_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 54){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").style.width = probabilityMax+"%";
              document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";
              document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 24');
            }
          }

        }
        if(six_cookie_first_size == 54){
          //alert("probabilityMax -- -- "+six_cookie_first_size);
          if(six_cookie_first_prob>84){
            //alert("probabilityMax 1"+probabilityMax);
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "104"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 56){
              document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 46 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('PB 25');
          }
          if(six_cookie_first_prob<84){
            //alert("probabilityMax 2"+probabilityMax);
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "104"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 56){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 46 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // --------------------------------------------------------
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('PB 26');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "104"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 56){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 46 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // --------------------------------------------------------
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('PB 27');
            }
          }
        }
        if(six_cookie_first_size != 48 && six_cookie_first_size != 50 && six_cookie_first_size != 52 && six_cookie_first_size != 54){
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").show();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").hide();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").hide();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').hide();
        }
      }
    }
    /* SCRIPT BASED ON IF SECOND SIZE LARGER */
    //alert("second size"+ six_cookie_first_prob+ " & " +six_cookie_second_prob);

    if(six_cookie_first_prob<six_cookie_second_prob){
      //alert("second size bigger "+probabilityMax);
      var probabilityMax = six_cookie_second_prob; // probability first (larger)
      var probabilityMin = six_cookie_first_prob; // probability first (smaller)
      // first larger
      var result_large0 = six_cookie_first_size; // US size
      var result_large1 = six_cookie_first_size+10;  // EU size
      // second smaller
      var result_large_a = six_cookie_second_size; // US size
      var result_large_aa = six_cookie_second_size+10;  // EU size
      if(Popup_First_Output_Size=="S"){
        jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").show(); 
        jQuery(".FitFinder-result_S-0").addClass("no_result");
        jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").hide(); jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").hide();
        jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').hide();
        document.getElementById("random__number_size").innerHTML = result_large1+" EU / "+result_large0+" - "+ Popup_First_Output_Size +" - "+" US";
        document.getElementById("random__numbera_size").innerHTML = result_large_aa+" EU / "+result_large_a+" - "+ Popup_First_Output_Size +" - "+" US";
        document.getElementById("random__number_a").style.width = probabilityMax+"%";
        document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
        document.getElementById("random__number_aa").style.width = probabilityMin+"%";
        document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
        console.log('Niche se PB 26');
      }
      if(Popup_First_Output_Size=="R"){
        if(six_cookie_first_size == 46){
          //alert("size first normal 46");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();
          jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(probabilityMax > 84 && probabilityMin < 16){
            document.getElementById("random__numbera_size").innerHTML = "44 EU / 34 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 44){
              document.getElementById("random__number_size").innerHTML = "46" +" EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 48){
              document.getElementById("random__numbera_size").innerHTML = " 48 EU / 38 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // -------------------------------------------------
            document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('Niche se PB 25');
          }
          if(probabilityMax < 84 && probabilityMin > 16){
            document.getElementById("random__number_size").innerHTML = "46" +" EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 44){
              document.getElementById("random__numbera_size").innerHTML = "44 EU / 34 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 48){
              document.getElementById("random__numbera_size").innerHTML = " 48 EU / 38 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // -------------------------------------------------
            document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
            document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
            console.log('Niche se PB 24');
          }
        }
        if(six_cookie_first_size == 48){
          //alert("probabilityMax "+probabilityMax+"probabilityMin "+probabilityMin);
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();
          jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(probabilityMax > 84 && probabilityMin < 16){
            document.getElementById("random__number_size").innerHTML = "46 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 46){
              document.getElementById("random__numbera_size").innerHTML = "48"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "50 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // ------------------------------------------
            document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('Niche se PB 23');
          }
          if(probabilityMax < 84 && probabilityMin > 16){
            document.getElementById("random__number_size").innerHTML = "48"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 46){
              document.getElementById("random__numbera_size").innerHTML = "46 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "50 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // ------------------------------------------
            document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
            document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
            console.log('Niche se PB 22');
          }
        }
        if(six_cookie_first_size == 50){
          console.log("-------------probabilityMax "+probabilityMax+"probabilityMin "+probabilityMin);
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();
          jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          document.getElementById("random__number_size").innerHTML = "52 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
          if(six_cookie_second_size == 48){
            document.getElementById("random__numbera_size").innerHTML = "48 EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
          }else if(six_cookie_second_size == 52){
            document.getElementById("random__numbera_size").innerHTML = "50"+" EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
          }
          // document.getElementById("random__number_a").style.width = probabilityMax  +"%";
          document.getElementById("random__number_a").innerHTML = probabilityMax  +"%";
          jQuery('#random__number_a').text(probabilityMax+'%');
          // document.getElementById("random__number_aa").style.width = probabilityMin +"%";
          document.getElementById("random__number_aa").innerHTML = probabilityMin +"%";
          jQuery('#random__number_aa').text(probabilityMin+'%');
          console.log('Niche se PB 21');
        }
        if(six_cookie_first_size == 52){
          //alert("size first normal 52");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(probabilityMax > 84 && probabilityMin < 16){
            document.getElementById("random__number_size").innerHTML = "52 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "52"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 54){
              document.getElementById("random__numbera_size").innerHTML = "54 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // ----------------------------------------
            document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('Niche se PB 20');
          }
          if(probabilityMax < 84 && probabilityMin > 16){
            document.getElementById("random__number_size").innerHTML = "52"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "50 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 54){
              document.getElementById("random__numbera_size").innerHTML = "54 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // ----------------------------------------
            document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
            document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
            console.log('Niche se PB 19');
          }
        }
        if(six_cookie_first_size == 54){
          //alert("size first normal 54");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
          if(probabilityMax > 84 && probabilityMin < 16){
            document.getElementById("random__number_size").innerHTML = "52 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "54"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 56){
              document.getElementById("random__numbera_size").innerHTML = "54 EU / "+" 46 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // -------------------------------------------
            document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
            document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
            console.log('Niche se PB 18');
          }
          if(probabilityMax < 84 && probabilityMin > 16){
            document.getElementById("random__number_size").innerHTML = "54"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "52 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 56){
              document.getElementById("random__numbera_size").innerHTML = "52 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            // -------------------------------------------
            document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
            document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
            console.log('Niche se PB 17');
          }
        }
        if(six_cookie_first_size != 46 && six_cookie_first_size != 48 && six_cookie_first_size != 50 && six_cookie_first_size != 52 && six_cookie_first_size != 54){
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").show();
          jQuery(".FitFinder-result_S-0").addClass("no_result");
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").hide();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").hide();
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').hide();
        }
      }
      // large 
      if(Popup_First_Output_Size=="L"){
        //alert("probability large 2 "+ probabilityMax);
        if(six_cookie_first_size == 48){
          if(six_cookie_first_prob>84){
            //alert("large size - 48");
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "94"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 46){
              document.getElementById("random__numbera_size").innerHTML = "90 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('Niche se PB 16');
          }
          if(six_cookie_first_prob<84){
            //alert("large size - 48");
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "90 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 46){
                document.getElementById("random__numbera_size").innerHTML = "94"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('Niche se PB 15');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "94"+" EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 46){
                document.getElementById("random__numbera_size").innerHTML = "90 EU / "+" 36 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // -------------------------------------
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('Niche se PB 14');
            }
          }
        }
        if(six_cookie_first_size == 50){
          if(six_cookie_first_prob>84){
            //alert("large size - 50");
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "98"+" EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 48){
              document.getElementById("random__numbera_size").innerHTML = "94 EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('Niche se PB 13');
          }
          if(six_cookie_first_prob<84){
            //alert("large size - 50");
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "94 EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = "98"+" EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // -----------------------------
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('Niche se PB 12');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 48){
                document.getElementById("random__numbera_size").innerHTML = "94 EU / "+" 38 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "98"+" EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // ------------------------------
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('Niche se PB 11');
            }
          }
        }
        if(six_cookie_first_size == 52){
          if(six_cookie_first_prob>84){
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "102"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 50){
              document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 54){
              document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('Niche se PB 10');
          }
          if(six_cookie_first_prob<84){
            //alert("large size - 52");
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "102"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 54){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('Niche se PB 9');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "102"+" EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 50){
                document.getElementById("random__numbera_size").innerHTML = "98 EU / "+" 40 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 54){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // ---------------------------
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('Niche se PB 8');
            }
          }

        }
        //six_cookie_first_size + "-" +six_cookie_first_prob + "-" +six_cookie_second_size + "-" +six_cookie_second_prob
        if(six_cookie_first_size == 54){
          //alert("six_cookie_first_prob------------------- "+six_cookie_first_size);
          if(six_cookie_first_prob>84){
            //alert("large size ------ " + probabilityMax);
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            document.getElementById("random__number_size").innerHTML = "104"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
            if(six_cookie_second_size == 52){
              document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
            }else if(six_cookie_second_size == 56){
              document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 46 "+""+ Popup_First_Output_Size +" - "+" US";
            }
            document.getElementById("random__number_a").style.width = "85%";
            document.getElementById("random__number_a").innerHTML = "85%";
            document.getElementById("random__number_aa").style.width = "15%";
            document.getElementById("random__number_aa").innerHTML = "15%";
            console.log('Niche se PB 7');
          }
          if(six_cookie_first_prob<84){
            //alert("large size six_cookie_first_prob ------ " + six_cookie_first_prob);
            jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").hide();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").show();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").show();
            jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').show();
            if(probabilityMax > 84 && probabilityMin < 16){
              document.getElementById("random__number_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "104"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 56){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 46 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // --------------------------------
              document.getElementById("random__number_a").innerHTML = "85"+"%";document.getElementById("random__number_a").style.width = "85"+"%";
              document.getElementById("random__number_aa").style.width = "15"+"%";document.getElementById("random__number_aa").innerHTML = "15"+"%";
              console.log('Niche se PB 6');
            }
            if(probabilityMax < 84 && probabilityMin > 16){
              document.getElementById("random__number_size").innerHTML = "104"+" EU / "+" 44 "+""+ Popup_First_Output_Size +" - "+" US";
              if(six_cookie_second_size == 52){
                document.getElementById("random__numbera_size").innerHTML = "102 EU / "+" 42 "+""+ Popup_First_Output_Size +" - "+" US";
              }else if(six_cookie_second_size == 56){
                document.getElementById("random__numbera_size").innerHTML = "104 EU / "+" 46 "+""+ Popup_First_Output_Size +" - "+" US";
              }
              // --------------------------------
              document.getElementById("random__number_a").style.width = probabilityMax+"%";document.getElementById("random__number_a").innerHTML = probabilityMax+"%";
              document.getElementById("random__number_aa").style.width = probabilityMin+"%";document.getElementById("random__number_aa").innerHTML = probabilityMin+"%";
              console.log('Niche se PB 5');
            }
          }
        }
        if(six_cookie_first_size != 48 && six_cookie_first_size != 50 && six_cookie_first_size != 52 && six_cookie_first_size != 54){
          jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_S-0").show();jQuery("div#TS-FitFinder--TS-7").find(".FitFinder-result_R-0").hide();jQuery("div#TS-FitFinder--TS-7").find("span.compare-msg").hide();
          jQuery(".FitFinder-result_S-0").addClass("no_result");
          jQuery('.TS-FitFinder-HTAY p.main-heading-HTAY').hide();
        }
      }
    }
  });
  /*================================================================
                                  END BASED ON PROCESSING BAR
        ================================================================*/ 


  /*================================================================
                                  START BASED ON ENTER NEXT
        ================================================================*/ 

  jQuery(document).on("keypress", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active input, label.radio_txt", function (e) {
    if(jQuery(this).val()>0){
      if (e.keyCode == 13) {

        console.log('You pressed enter! 1');
        var $this_elem = jQuery(this);
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=text]').focus();
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=range]').focus();
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=range]').click();
        setTimeout(function(){
          console.log('update data-active-slide value');
          var stepNum = jQuery('.TS-FitFinder-HTAY.FitFinder-Active').attr('data-step');
          jQuery('.TS-FitFinder-Main').attr('data-active-slide',stepNum);
        },100);
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('fadeInRight animated');
        if($this_elem.parents('.TS-FitFinder-HTAY.FitFinder-Active').attr('data-step') == 'step-1'){
          $this_elem.parents('.TS-FitFinder-HTAY.FitFinder-Active').addClass('fadeOutLeft animated');
        }

        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('FitFinder-Active');

        $this_elem.parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('fadeInRight');
        $this_elem.parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('animated');
        setTimeout(function(){
          console.log('animation classes removed -- ');
          $this_elem.attr('data-testing','this is it');
          $this_elem.parents('.TS-FitFinder-HTAY').removeClass('fadeInRight');
          $this_elem.parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('animated');

          if($this_elem.parents('.TS-FitFinder-HTAY.FitFinder-Active').attr('data-step') == 'step-1'){
            $this_elem.parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('fadeOutLeft animated');
          }

        },1500);
      }
    }
  });
  jQuery(document).on("click", "label.radio_txt", function (e) {
    console.log('You pressed enter! 2');
    console.log('mobile direct transition stopped for step 7');

    //         jQuery(".text-center.main-steps--HTAY").find(".round-all").removeClass("active");
    //         jQuery(".text-center.main-steps--HTAY").find(".round-all").addClass("disabled");
    //         jQuery("span.step-7.round-all.disabled").find("span.step-7.round-all").removeClass("disabled");
    //         jQuery("span.step-7.round-all.disabled").find("span.step-7.round-all").addClass("active");
    //         jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active');
    //         jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('fadeInRight animated');
    //         jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('FitFinder-Active');
    //         jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('fadeInRight animated');
  });
  jQuery(document).on("keypress", "input#input-type-HTAY-main", function (e) {
    console.log('LKL 01');
    //jQuery(".text-center.main-steps--HTAY").find(".round-all").removeClass("active");
    if(jQuery(this).val()>0){
      if (e.keyCode == 13) {
        console.log('gnja 01');
        jQuery(".text-center.main-steps--HTAY").find(".round-all").removeClass("active");
        setTimeout(function(){
          console.log('gnja 02');
          jQuery(".text-center.main-steps--HTAY").find("span.step-2").addClass("active");
        },50);
      }
    }
  });
  jQuery(document).on("keypress", '.FitFinder-Step-Grand', function (eve) {
    console.log('this is enter here 12 !!!!!!!');
    if(jQuery(this).find('input[type="radio"]').is(":checked")){
      if (eve.keyCode == 13) {
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=text]').focus();
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=range]').focus();
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=range]').click();
        setTimeout(function(){
          console.log('update data-active-slide value');
          var stepNum = jQuery('.TS-FitFinder-HTAY.FitFinder-Active').attr('data-step');
          jQuery('.TS-FitFinder-Main').attr('data-active-slide',stepNum);
        },100);
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('FitFinder-Active');
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('fadeInRight animated');
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('fadeInRight animated');
      }
    }
  });
  jQuery(document).on("keypress", 'label.radio_txt', function (evae) {
    console.log('this is enter here 13 !!!!!!!');
    if(jQuery(this).find('input[type="radio"]').is(":checked")){
      if (evae.keyCode == 13) {
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=text]').focus();
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=range]').focus();
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active').find('input[type=range]').click();
        setTimeout(function(){
          console.log('update data-active-slide value');
          var stepNum = jQuery('.TS-FitFinder-HTAY.FitFinder-Active').attr('data-step');
          jQuery('.TS-FitFinder-Main').attr('data-active-slide',stepNum);
        },100);
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('FitFinder-Active');
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('fadeInRight animated');
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('fadeInRight animated');
      }
    }
  });
  jQuery(document).on("keypress", "body", function (enterr) {
    console.log('this is enter here 14 !!!!!!!');
    if (enterr.keyCode == 13) {
      if(jQuery("div#TS-FitFinder--TS-1").hasClass('FitFinder-Active')){
        if(jQuery("div#TS-FitFinder--TS-1").find("input").val()!=0){
          jQuery(".steps-HTAY").find("span.step-1.round-all").click();
          jQuery(".steps-HTAY").find("span.step-1.round-all").trigger("click");
        }
      }
      if(jQuery("div#TS-FitFinder--TS-2").hasClass('FitFinder-Active')){
        if(jQuery("div#TS-FitFinder--TS-2").find("input").val()!=0){
          jQuery(".steps-HTAY").find("span.step-2.round-all").click();
          jQuery(".steps-HTAY").find("span.step-2.round-all").trigger("click");
        }
      }
      if(jQuery("div#TS-FitFinder--TS-3").hasClass('FitFinder-Active')){
        if(jQuery("div#TS-FitFinder--TS-3").find("input").val()!=0){
          jQuery(".steps-HTAY").find("span.step-3.round-all").click();
          jQuery(".steps-HTAY").find("span.step-3.round-all").trigger("click");
        }
      }
      if(jQuery("div#TS-FitFinder--TS-4").hasClass('FitFinder-Active')){
        //console.log('this is enter here 44 !!!!!!!');
        if(jQuery("div#TS-FitFinder--TS-4").find("input").val()!=0){
          //console.log('working 44 !!!!!!!');
          jQuery(".steps-HTAY").find("span.step-4.round-all").click();
          jQuery(".steps-HTAY").find("span.step-4.round-all").trigger("click");
        }
      }
      if(jQuery("div#TS-FitFinder--TS-5").hasClass('FitFinder-Active')){
        //console.log('this is enter here 55 !!!!!!!');
        if(jQuery("div#TS-FitFinder--TS-5").find("input").val()!=0 || jQuery("div#TS-FitFinder--TS-5").find("input").val()== ''){
          //console.log('working 55 !!!!!!!');
          jQuery(".steps-HTAY").find("span.step-5.round-all").click();
          jQuery(".steps-HTAY").find("span.step-5.round-all").trigger("click");

          console.log('default fit preference set');
          var the_elem_nt = jQuery("#range-main-input-FP");
          the_elem_nt.attr("Fit-Pref", "NORMAL");
          the_elem_nt.attr("data-choice", "NORMAL");
          Cookies.set('f_preference_value', "NORMAL");
        }
      }
      if(jQuery("div#TS-FitFinder--TS-6").hasClass('FitFinder-Active')){
        if(jQuery("div#TS-FitFinder--TS-6").find("input").val()!=0){
          jQuery(".steps-HTAY").find("span.step-6.round-all").click();
          jQuery(".steps-HTAY").find("span.step-6.round-all").trigger("click");             
        }
      }
      if(jQuery("div#TS-FitFinder--TS-7").hasClass('FitFinder-Active')){
        if(jQuery("div#TS-FitFinder--TS-7").find("input").val()!=0){
          jQuery(".steps-HTAY").find("span.step-7.round-all").click();
          jQuery(".steps-HTAY").find("span.step-7.round-all").trigger("click");
        }
      }
    }
  });

  /*================================================================
                                  END BASED ON ENTER NEXT
                ================================================================*/ 
  jQuery(document).on("click", "span.step-1", function(){
    console.log('this is step One ====>');
    var step_num = jQuery('.TS-FitFinder-Main').attr('data-active-slide');
    var step_num_split= step_num.split('-');
    var step_num = parseInt(step_num_split[1]);
    console.log('the current step is:-->'+step_num);
    if(step_num > 1){
      var outSlide = 'div#TS-FitFinder--TS-'+step_num;
      console.log('Out slide-> Step-'+step_num);
      jQuery(outSlide).addClass("fadeOutRight animated");
      jQuery("div#TS-FitFinder--TS-1").addClass("fadeInLeft animated");
      jQuery('.TS-Fit-Submit button.btn').show();
      jQuery('.continue-TXT').show();
      jQuery('.continue-TXT_mobile.mobile_text_press').show();

      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-1").removeClass("fadeInLeft animated");
      }, 2000);
      jQuery('.continue-TXT_mobile.mobile_text_press').show();

      jQuery('.continue-TXT').show();
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-1").removeClass("fadeInLeft animated");
      }, 2500);
      jQuery('.continue-TXT_mobile.mobile_text_press').show();

      jQuery('.continue-TXT').show();
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-1").removeClass("fadeInLeft animated");
      }, 3000);
    }
  });
  jQuery(document).on("click", "span.step-2", function(){
    jQuery('.continue-TXT_mobile.mobile_text_press').show();

    console.log('this is step Two ====>');
    var step_num = jQuery('.TS-FitFinder-Main').attr('data-active-slide');
    var step_num_split= step_num.split('-');
    var step_num = parseInt(step_num_split[1]);
    console.log('the current step is:-->'+step_num);
    if(step_num > 2){
      var outSlide = 'div#TS-FitFinder--TS-'+step_num;
      console.log('Out slide-> Step-'+step_num);

      jQuery(outSlide).addClass("fadeOutRight animated");
      jQuery("div#TS-FitFinder--TS-2").addClass("fadeInLeft animated");
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-2").removeClass("fadeInLeft animated");
      }, 2000);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-2").removeClass("fadeInLeft animated");
      }, 2500);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-2").removeClass("fadeInLeft animated");
      }, 3000);
    }
    else{
      if(step_num != 2){
        jQuery("div#TS-FitFinder--TS-1").addClass("fadeOutLeft animated");
        jQuery("div#TS-FitFinder--TS-2").addClass("fadeInRight animated");
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-1").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-2").removeClass("fadeInRight animated");
        }, 2000);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-1").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-2").removeClass("fadeInRight animated");
        }, 2500);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-1").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-2").removeClass("fadeInRight animated");
        }, 3000);
      }
    }
  });
  jQuery(document).on("click", "span.step-3", function(){
    jQuery('.continue-TXT_mobile.mobile_text_press').hide();

    console.log('this is step Three ====>');

    var step_num = jQuery('.TS-FitFinder-Main').attr('data-active-slide');
    var step_num_split= step_num.split('-');
    var step_num = parseInt(step_num_split[1]);
    console.log('the current step is:-->'+step_num);
    if(step_num > 3){
      var outSlide = 'div#TS-FitFinder--TS-'+step_num;
      console.log('Out slide-> Step-'+step_num);

      jQuery(outSlide).addClass("fadeOutRight animated");
      jQuery("div#TS-FitFinder--TS-3").addClass("fadeInLeft animated");

      jQuery('.continue-TXT').hide();
      setTimeout(function(){
        jQuery(outSlide).addClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-3").removeClass("fadeInLeft animated");
      }, 2000);
      setTimeout(function(){
        jQuery(outSlide).addClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-3").removeClass("fadeInLeft animated");
      }, 2500);
      setTimeout(function(){
        jQuery(outSlide).addClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-3").removeClass("fadeInLeft animated");
      }, 3000);

    }else{ 
      if(step_num != 3){
        jQuery("div#TS-FitFinder--TS-2").addClass("fadeOutLeft animated");
        jQuery("div#TS-FitFinder--TS-3").addClass("fadeInRight animated");

        jQuery('.continue-TXT').hide();
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-2").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-3").removeClass("fadeInRight animated");
        }, 2000);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-2").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-3").removeClass("fadeInRight animated");
        }, 2500);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-2").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-3").removeClass("fadeInRight animated");
        }, 3000);
      }
    }
  });
  jQuery(document).on("click", "span.step-4", function(){

    console.log('this is step Four ====>');
    jQuery('.continue-TXT_mobile.mobile_text_press').hide();

    var step_num = jQuery('.TS-FitFinder-Main').attr('data-active-slide');
    var step_num_split= step_num.split('-');
    var step_num = parseInt(step_num_split[1]);
    console.log('the current step is:-->'+step_num);
    if(step_num > 4){
      var outSlide = 'div#TS-FitFinder--TS-'+step_num;
      console.log('Out slide-> Step-'+step_num);

      jQuery(outSlide).addClass("fadeOutRight animated");
      jQuery("div#TS-FitFinder--TS-4").addClass("fadeInLeft animated");
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-4").removeClass("fadeInLeft animated");
      }, 2000);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-4").removeClass("fadeInLeft animated");
      }, 2500);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-4").removeClass("fadeInLeft animated");
      }, 3000);

    }else{
      if(step_num != 4){
        jQuery("div#TS-FitFinder--TS-3").addClass("fadeOutLeft animated");
        jQuery("div#TS-FitFinder--TS-4").addClass("fadeInRight animated");
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-3").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-4").removeClass("fadeInRight animated");
        }, 2000);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-3").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-4").removeClass("fadeInRight animated");
        }, 2500);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-3").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-4").removeClass("fadeInRight animated");
        }, 3000);
      }
    }
  });
  jQuery(document).on("click", "span.step-5", function(){
    console.log('this is step Five ====>');
    jQuery('.TS-Fit-Submit button.btn').show();
    jQuery('.continue-TXT').show();
    jQuery('.continue-TXT_mobile.mobile_text_press').show();

    var step_num = jQuery('.TS-FitFinder-Main').attr('data-active-slide');
    var step_num_split= step_num.split('-');
    var step_num = parseInt(step_num_split[1]);
    console.log('the current step is:-->'+step_num);
    if(step_num > 5){
      var outSlide = 'div#TS-FitFinder--TS-'+step_num;
      console.log('Out slide-> Step-'+step_num);

      jQuery(outSlide).addClass("fadeOutRight animated");
      jQuery("div#TS-FitFinder--TS-5").addClass("fadeInLeft animated");
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-5").removeClass("fadeInLeft animated");
      }, 2000);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-5").removeClass("fadeInLeft animated");
      }, 2500);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-5").removeClass("fadeInLeft animated");
      }, 3000);

    }else{
      if(step_num != 5){

        jQuery("div#TS-FitFinder--TS-4").addClass("fadeOutLeft animated");
        jQuery("div#TS-FitFinder--TS-5").addClass("fadeInRight animated");
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-4").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-5").removeClass("fadeInRight animated");
        }, 2000);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-4").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-5").removeClass("fadeInRight animated");
        }, 2500);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-4").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-5").removeClass("fadeInRight animated");
        }, 3000);
      }
    }
  });
  jQuery(document).on("click", "span.step-6", function(){
    console.log('this is step Six ====>');
    jQuery('.continue-TXT_mobile.mobile_text_press').hide();

    var step_num = jQuery('.TS-FitFinder-Main').attr('data-active-slide');
    var step_num_split= step_num.split('-');
    var step_num = parseInt(step_num_split[1]);
    console.log('the current step is:-->'+step_num);
    if(step_num > 6){
      var outSlide = 'div#TS-FitFinder--TS-'+step_num;
      console.log('Out slide-> Step-'+step_num);

      jQuery(outSlide).addClass("fadeOutRight animated");
      jQuery("div#TS-FitFinder--TS-6").addClass("fadeInLeft animated");
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-6").removeClass("fadeInLeft animated");
      }, 2000);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-6").removeClass("fadeInLeft animated");
      }, 2500);
      setTimeout(function(){
        jQuery(outSlide).removeClass("fadeOutRight animated");
        jQuery("div#TS-FitFinder--TS-6").removeClass("fadeInLeft animated");
      }, 3000);

    }else{
      if(step_num != 6){

        jQuery("div#TS-FitFinder--TS-5").addClass("fadeOutLeft animated");
        jQuery("div#TS-FitFinder--TS-6").addClass("fadeInRight animated");
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-5").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-6").removeClass("fadeInRight animated");
        }, 2000);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-5").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-6").removeClass("fadeInRight animated");
        }, 2500);
        setTimeout(function(){
          jQuery("div#TS-FitFinder--TS-5").removeClass("fadeOutLeft animated");
          jQuery("div#TS-FitFinder--TS-6").removeClass("fadeInRight animated");
        }, 3000);
      }
    }
  });
  jQuery(document).on("click", "span.step-7", function(){ 
    console.log('this is step Seven ====>');
    jQuery('.continue-TXT_mobile.mobile_text_press').show();

    jQuery("div#TS-FitFinder--TS-6").addClass("fadeOutLeft animated");
    jQuery("div#TS-FitFinder--TS-7").addClass("fadeInRight animated");
    setTimeout(function(){
      jQuery("div#TS-FitFinder--TS-6").removeClass("fadeOutLeft animated");
      jQuery("div#TS-FitFinder--TS-7").removeClass("fadeInRight animated");
    }, 2000);
    setTimeout(function(){
      jQuery("div#TS-FitFinder--TS-6").removeClass("fadeOutLeft animated");
      jQuery("div#TS-FitFinder--TS-7").removeClass("fadeInRight animated");
    }, 2500);
    setTimeout(function(){
      jQuery("div#TS-FitFinder--TS-6").removeClass("fadeOutLeft animated");
      jQuery("div#TS-FitFinder--TS-7").removeClass("fadeInRight animated");
    }, 3000);
    if(Cookies.get("Popup_Sixth_Output") == 'null'){
      console.log('WRONG RESULTS NO RESULTS');
      jQuery('.FitFinder-result_S-0 span.compare-msg,.TS-FitFinder-HTAY p.main-heading-HTAY,.FitFinder-result_R-0,span.compare-msg,.steps-HTAY').hide();
      jQuery('.FitFinder-result_S-0 ').addClass("comapre_result");
      jQuery("div#TS-FitFinder--TS-6").removeClass("fadeOutLeft animated");
      jQuery("div#TS-FitFinder--TS-7").removeClass("fadeInRight animated");
    }else{
      jQuery("#random__number_a").css({"width": "0"});
      jQuery("#random__number_a").animate({width: jQuery("#random__number_a").text(), marginLeft: 0}, {duration: 2200});
      jQuery("#random__number_aa").css({"width": "0"});
      jQuery("#random__number_aa").animate({width: jQuery("#random__number_aa").text(), marginLeft: 0}, {duration: 2200});
      console.log('click for step results!!!!!')
    }
  });
  jQuery(document).on("click", "span.step-8", function(){
    console.log('this is step Eight ====>');
    jQuery("div#TS-FitFinder--TS-8").addClass("fadeInRight animated");
    setTimeout(function(){
      jQuery("div#TS-FitFinder--TS-8").removeClass("fadeInRight animated");
    }, 3000);
  });
  // disabled enable
  jQuery(document).on("mousemove", "body", function(event){
    var aHTRY = jQuery("input#input-type-HTAY-main").val();
    var aWIYW = jQuery("input#input-type-WIYW-main").val();

    var aBS1 = jQuery('input.checkbox-BS[belly-type="Skinny"]').is(":checked");
    var aBS2 = jQuery('input.checkbox-BS[belly-type="Normal"]').is(":checked");
    var aBS3 = jQuery('input.checkbox-BS[belly-type="Rounder"]').is(":checked");

    var aSW1 = jQuery('input.checkbox-SW[shoulder-type="Narrow"]').is(":checked");
    var aSW2 = jQuery('input.checkbox-SW[shoulder-type="Normal"]').is(":checked");
    var aSW3 = jQuery('input.checkbox-SW[shoulder-type="Wide"]').is(":checked");

    var aHORU = jQuery("input#input-type-HORU-main").val();
    if(aHTRY.length > 0){
      jQuery("span.step-2.round-all").removeClass("disabled");
      jQuery("span.step-3.round-all").addClass("disabled");
      jQuery("span.step-4.round-all").addClass("disabled");
      jQuery("span.step-5.round-all").addClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }
    if(aHTRY.length < 1){
      jQuery("span.step-2.round-all").addClass("disabled");
      jQuery("span.step-3.round-all").addClass("disabled");
      jQuery("span.step-4.round-all").addClass("disabled");
      jQuery("span.step-5.round-all").addClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }

    if(aHTRY.length > 0 && aWIYW.length > 0){
      jQuery("span.step-3.round-all").removeClass("disabled");
      jQuery("span.step-4.round-all").addClass("disabled");
      jQuery("span.step-5.round-all").addClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }
    if(aHTRY.length < 1 && aWIYW.length < 1){
      jQuery("span.step-3.round-all").addClass("disabled");
      jQuery("span.step-4.round-all").addClass("disabled");
      jQuery("span.step-5.round-all").addClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }

    if(aHTRY.length > 0 && aWIYW.length > 0 && (aBS1 || aBS2 || aBS3) ){
      jQuery("span.step-4.round-all").removeClass("disabled");
      jQuery("span.step-5.round-all").addClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }
    if(aHTRY.length < 1 && aWIYW.length < 1 && (!aBS1 || !aBS2 || !aBS3)  ){
      jQuery("span.step-4.round-all").addClass("disabled");
      jQuery("span.step-5.round-all").addClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }

    if(aHTRY.length > 0 && aWIYW.length > 0 && (aBS1 || aBS2 || aBS3) && (aSW1 || aSW2 || aSW3)){
      jQuery("span.step-5.round-all").removeClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }
    if(aHTRY.length < 1 && aWIYW.length < 1 && (!aBS1 || !aBS2 || !aBS3) && (!aSW1 || !aSW2 || !aSW3)){
      jQuery("span.step-5.round-all").addClass("disabled");
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }

    if(aHTRY.length > 0 && aWIYW.length > 0 && (aBS1 || aBS2 || aBS3) && (aSW1 || aSW2 || aSW3)){
      jQuery("span.step-6.round-all").removeClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }
    if(aHTRY.length < 1 && aWIYW.length < 1 && (!aBS1 || !aBS2 || !aBS3) && (!aSW1 || !aSW2 || !aSW3)){
      jQuery("span.step-6.round-all").addClass("disabled");
      jQuery("span.step-7.round-all").addClass("disabled");
    }

    if(aHTRY.length > 0 && aWIYW.length > 0 && (aBS1 || aBS2 || aBS3) && (aSW1 || aSW2 || aSW3) && aHORU > 0){
      jQuery("span.step-7.round-all").removeClass("disabled");
    }
    if(aHTRY.length < 1 && aWIYW.length < 1 && (!aBS1 || !aBS2 || !aBS3) && (!aSW1 || !aSW2 || !aSW3) && aHORU > 0){
      jQuery("span.step-7.round-all").addClass("disabled");
    }



    /* Continue button disable/ enable  */
    if(jQuery(window).width() >= 768){
      //console.log('Width is greater than or equal to 768');
      var ActiveInputType = jQuery('.FitFinder-Active').find('input').attr('class');
      var input_type = jQuery('.FitFinder-Active').find('input').attr('type');
      /* If input type is text */
      if(input_type == 'text'){
        //console.log('Input Type is -> Text ');
        var input_val = jQuery('.FitFinder-Active').find('input').val();
        if(input_val != ''){
          jQuery('.TS-Fit-Submit button[type="button"]').removeAttr('disabled');
        }else{
          jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
        }
      }
      /* If input type is radio */
      if(input_type == 'radio'){
        jQuery('.TS-Fit-Submit button[type="button"]').hide();

      }


      /* If input type is Range */
      var input_type_range = jQuery('.FitFinder-Active .desktop--only-ts').find('input').attr('type');
      if(input_type_range == 'range'){
        //console.log('Input Typeis -> Range');
        console.log(typeof jQuery('.FitFinder-Active').find('input[type="range"]').attr('data-choice'));
        if(typeof jQuery('.FitFinder-Active').find('input[type="range"]').attr('data-choice') == 'undefined'){
          jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
        }else{
          jQuery('.TS-Fit-Submit button[type="button"]').removeAttr('disabled');
        }
      }
    }


    if(jQuery('.FitFinder-Active').attr('data-step') == 'step-7'){
      //console.log('Step 7 is achived');
      jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
    }

    if(jQuery(window).width() < 768){
      //            var ActiveInputType = jQuery('.FitFinder-Active').find('input').attr('class');
      //         var input_type = jQuery('.FitFinder-Active').find('input').attr('type');
      if(input_type == 'radio'){
        jQuery('.TS-Fit-Submit button[type="button"]').show();
        //         var rangeRadio =jQuery('.FitFinder-Active .mobile--only-ts').find('input').attr('class');
        //           if(rangeRadio != ActiveInputType){
        //             //console.log('Input Type is -> Radio');
        //             if(jQuery('.FitFinder-Active').find('input[type="radio"]').is(":checked")){
        //               jQuery('.TS-Fit-Submit button[type="button"]').removeAttr('disabled');
        //             }else{
        //               jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
        //             }
        //           }

      }

    }

  });
  // result with progress desktop
  jQuery(document).on("keypress", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active input", function (e) {
    if(jQuery(this).val()>0){
      if (e.keyCode == 13) {
        jQuery("#random__number_a").css({"width": "0"});
        jQuery("#random__number_a").animate({width: jQuery("#random__number_a").text(), marginLeft: 0}, {duration: 2200});
        jQuery("#random__number_aa").css({"width": "0"});
        jQuery("#random__number_aa").animate({width: jQuery("#random__number_aa").text(), marginLeft: 0}, {duration: 2200});
        console.log('Niche se PB 4');
      }
    }
  });
  // result with progress mobile 
  //   jQuery(document).on("keypress", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active label.radio_txt", function (e) {
  //     if(jQuery(this).val()>0){
  //       if (e.keyCode == 13) {
  //         jQuery("#random__number_a").css({"width": "0"});
  //         jQuery("#random__number_a").animate({width: jQuery("#random__number_a").text(), marginLeft: 0}, {duration: 2200});
  //         jQuery("#random__number_aa").css({"width": "0"});
  //         jQuery("#random__number_aa").animate({width: jQuery("#random__number_aa").text(), marginLeft: 0}, {duration: 2200});
  //       }
  //     }
  //   });
  // set value zero
  jQuery('span[data-step="step-1"]').click(function(){
    jQuery(".TS-FitFinder-Main").find("input#input-type-WIYW-main").val('');
    jQuery(".TS-FitFinder-Main").find("input#input-type-HORU-main").val('');
    jQuery(".TS-FitFinder-Main").find("img").removeClass('img-with-border-BS');
    jQuery(".TS-FitFinder-Main").find("img").removeClass('img-with-border-SW');
    jQuery(".TS-FitFinder-Main").find("input").removeAttr("checked");
    jQuery(".TS-FitFinder-Main").find("input").prop("checked", false);
  });





  // mobile jquery for range
  jQuery(document).on("click", "label.radio_txt", function(result){
    if(jQuery(this).val()>0){
      if (result.keyCode == 13) {
        jQuery("#random__number_a").css({"width": "0"});
        jQuery("#random__number_a").animate({width: jQuery("#random__number_a").text(), marginLeft: 0}, {duration: 2200});
        jQuery("#random__number_aa").css({"width": "0"});
        jQuery("#random__number_aa").animate({width: jQuery("#random__number_aa").text(), marginLeft: 0}, {duration: 2200});
        console.log('Niche se PB 3');
      }
    }
    var radio_fit_pref = jQuery(this).find("span.value_content").text();
    console.log('radio_fit_pref------>'+radio_fit_pref);
    jQuery("input#range-main-input-FP").attr("fit-pref", radio_fit_pref);
    jQuery(".c-range-main-input-FP").click();
    jQuery(".c-range-main-input-FP").trigger("click");
  });
  // bellu shape scirpt slider
  jQuery("div#TS-FitFinder--TS-3").find(".owl-dots button:nth-child(1) span").text("FLATTER");
  jQuery("div#TS-FitFinder--TS-3").find(".owl-dots button:nth-child(2) span").text("AVERAGE");
  jQuery("div#TS-FitFinder--TS-3").find(".owl-dots button:nth-child(3) span").text("ROUNDER");
  jQuery("div#TS-FitFinder--TS-4").find(".owl-dots button:nth-child(1) span").text("SLIMMER");
  jQuery("div#TS-FitFinder--TS-4").find(".owl-dots button:nth-child(2) span").text("AVERAGE");
  jQuery("div#TS-FitFinder--TS-4").find(".owl-dots button:nth-child(3) span").text("BROADER");

  // script for first popup
  // fitfinder
  jQuery(document).on("keyup", "input.measure_box__a_1", function(){
    if(jQuery(this).val().length==1){
      jQuery("input.measure_box_b_2").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_b_2", function(){
    if(jQuery(this).val().length==0){
      jQuery("input.measure_box__a_1").focus();
    }
  });

  /* ---------------------------------------------------------- */

  jQuery(document).on("keyup", "input.measure_box_1_horu", function(){
    if(jQuery(this).val().length==1){
      jQuery("input.measure_box_2_horu").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_2_horu", function(){
    if(jQuery(this).val().length==0){
      jQuery("input.measure_box_1_horu").focus();
    }
  });

  /* ---------------------------------------------------------- */

  jQuery(document).on("keyup", "input.measure_box_1", function(){
    if(jQuery(this).val().length==1){
      jQuery("input.measure_box_2").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_2", function(){
    if(jQuery(this).val().length==1){
      jQuery("input.measure_box_3").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_3", function(){
    if(jQuery(this).val().length==0){
      jQuery("input.measure_box_2").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_2", function(){
    if(jQuery(this).val().length==0){
      jQuery("input.measure_box_1").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_1_wiyw", function(){
    if(jQuery(this).val().length==1){
      jQuery("input.measure_box_2_wiyw").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_2_wiyw", function(){
    if(jQuery(this).val().length==1){
      jQuery("input.measure_box_3_wiyw").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_3_wiyw", function(){
    if(jQuery(this).val().length==0){
      jQuery("input.measure_box_2_wiyw").focus();
    }
  });
  jQuery(document).on("keyup", "input.measure_box_2_wiyw", function(){
    if(jQuery(this).val().length==0){
      jQuery("input.measure_box_1_wiyw").focus();
    }
  });



  /*============================== Mobile Jquery ========================================
      =======================================================================================
      =====================================================================================*/


  jQuery(document).on("keyup", "input.measure_box_3", function(){
    var firstpopupValue = jQuery(this).val();
    var howTallYouAre = firstpopupValue;
    var howTallYouAre1 = jQuery(".measure_box_1").val();
    var howTallYouAre2 = jQuery(".measure_box_2").val();
    var howTallYouAre_Unit = Cookies.get('height-unit');
    Cookies.set('height-value', howTallYouAre+howTallYouAre_Unit);
    var currentUnitForTallerShorter = jQuery(this).closest(".TS-FitFinder-HTAY").find("label").attr("unit");
    var howTallYouAre_All = howTallYouAre1+howTallYouAre2+howTallYouAre;
    console.log('howTallYouAre1'+howTallYouAre1+' howTallYouAre2'+howTallYouAre2+' howTallYouAre'+howTallYouAre+' Total'+howTallYouAre_All);
    /*if(howTallYouAre < 163) { var heightResult = 'smaller'; }
                    if(howTallYouAre > 191) { var heightResult = 'larger'; }
                    if(howTallYouAre < 163 && howTallYouAre > 191) { var heightResult = 'Regular'; }
                    Cookies.set('result-value', 'heightResult');*/
    // If Small --------------- Inches & Centimeters ---------------] 
    // If Regular Size

    // If CENTIMETERS
    if(!jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
      console.log('mob keyup 1');
      if(jQuery.trim(howTallYouAre_Unit) == "cm" && (jQuery.trim(howTallYouAre_All) < parseInt(163) || jQuery.trim(howTallYouAre_All) == parseInt(163))){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "S-"+howTallYouAre1+howTallYouAre2+howTallYouAre+"-CM");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "cm" && (jQuery.trim(howTallYouAre_All) > parseInt(163) && jQuery.trim(howTallYouAre_All) < parseInt(188))){
        console.log('R 1');
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "R-"+howTallYouAre1+howTallYouAre2+howTallYouAre+"-CM");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "cm" && (jQuery.trim(howTallYouAre_All) > parseInt(188) || jQuery.trim(howTallYouAre_All) == parseInt(188))){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "L-"+howTallYouAre1+howTallYouAre2+howTallYouAre+"-CM");
      }
    }
  });
  jQuery(document).on("keyup", "input.measure_box_3", function(){
    var firstpopupValue = jQuery(this).val();
    var howTallYouAre = firstpopupValue;
    var howTallYouAre1 = jQuery(".measure_box_1").val();
    var howTallYouAre2 = jQuery(".measure_box_2").val();
    var howTallYouAre_Unit = Cookies.get('height-unit');
    Cookies.set('height-value', howTallYouAre+howTallYouAre_Unit);
    var currentUnitForTallerShorter = jQuery(this).closest(".TS-FitFinder-HTAY").find("label").attr("unit");
    var howTallYouAre_All0 = howTallYouAre1+howTallYouAre2+howTallYouAre;
    /*if(howTallYouAre < 163) { var heightResult = 'smaller'; }
                    if(howTallYouAre > 191) { var heightResult = 'larger'; }
                    if(howTallYouAre < 163 && howTallYouAre > 191) { var heightResult = 'Regular'; }
                    Cookies.set('result-value', 'heightResult');*/
    // If Small --------------- Inches & Centimeters ---------------] 
    // If Regular Size

    //  If INCHES
    if(jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
      console.log('mob keyup 2');
      //console.log("Checked Inches howTallYouAre "+howTallYouAre);
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (jQuery.trim(howTallYouAre_All0) < parseInt(64) || jQuery.trim(howTallYouAre_All0) == parseInt(64))){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "S-"+howTallYouAre1+howTallYouAre2+howTallYouAre+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (jQuery.trim(howTallYouAre_All0) > parseInt(64) && jQuery.trim(howTallYouAre_All0) < parseInt(74))){
        console.log('R 2');
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "R-"+howTallYouAre1+howTallYouAre2+howTallYouAre+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (jQuery.trim(howTallYouAre_All0) > parseInt(74) || jQuery.trim(howTallYouAre_All0) == parseInt(74))){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "L-"+howTallYouAre1+howTallYouAre2+howTallYouAre+"-IN");
      }
    }
  });
  // only fee and  inches
  jQuery(document).on("keyup", "input.measure_box_b_2", function(){
    console.log('mob keyup 3');
    //alert("measure_box__a_1");
    var howTallYouAre_Unit = Cookies.get('height-unit');
    var valueInFeet = parseInt(jQuery("input.measure_box__a_1").val());
    var FeetToInches = valueInFeet*12;
    var valueInInches = parseInt(jQuery(this).val());
    var totalValue = FeetToInches+valueInInches;
    //alert(totalValue);
    if(jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
      //console.log("Checked Inches howTallYouAre "+howTallYouAre);
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (totalValue < 64 || totalValue == 64)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","S");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "S-"+totalValue+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (totalValue > 64 && totalValue < 74)){
        console.log('R 3');
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","R");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "R-"+totalValue+"-IN");
      }
      if(jQuery.trim(howTallYouAre_Unit) == "in" && (totalValue > 74 || totalValue == 74)){
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").text(jQuery(this).val()+"-"+"L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("span-type","L");
        jQuery(this).closest(".TS-FitFinder-HTAY").find("section.FitFinder-final-HTAY final").attr("Unit",howTallYouAre_Unit);
        Cookies.set('Popup_First_Output', "L-"+totalValue+"-IN");
      }
    }
  });

  jQuery(document).on("keyup", "input.measure_box_3_wiyw", function(){
    var firstpopupValue = jQuery(this).val();
    var firstpopupValue0 = jQuery(".measure_box_1_wiyw").val();
    var firstpopupValue1 = jQuery(".measure_box_2_wiyw").val();
    var whatIsYOurWeight001 = firstpopupValue0+firstpopupValue1+firstpopupValue;
    var whatIsYOurWeight = parseInt(whatIsYOurWeight001);
    //alert(whatIsYOurWeight);
    var whatIsYOurWeight_Unit = Cookies.get('weight-unit');
    Cookies.set('weight-value', whatIsYOurWeight+whatIsYOurWeight_Unit);
    var currentUnitForTallerShorter = jQuery(this).closest(".TS-FitFinder-HTAY").find("label").attr("unit");
    // If KILOGRAM
    if(jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-WIYW").is(":checked")){
      if(jQuery.trim(whatIsYOurWeight_Unit) == "lbs"){
        console.log("lbs");
        jQuery("#measure_box_1").show();
        if(whatIsYOurWeight > 143 && whatIsYOurWeight < 163){
          if(whatIsYOurWeight == Math.ceil(66*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(67*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-48~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(68*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-48~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(69*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-80%, Correct_Size_Second-48~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(70*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-73%, Correct_Size_Second-48~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(71*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-48~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(72*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-48~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(73*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 214 && whatIsYOurWeight < 181){
          if(whatIsYOurWeight == Math.ceil(74*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-46~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(75*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-46~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(76*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-46~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(77*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-80%, Correct_Size_Second-46~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(78*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-73%, Correct_Size_Second-50~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(79*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(80*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-50~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == Math.ceil(81*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 179 && whatIsYOurWeight < 196){
          if(whatIsYOurWeight == Math.ceil(82*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(83*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-48~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(84*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-48~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(85*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(86*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(87*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(88*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 194 && whatIsYOurWeight < 209){
          if(whatIsYOurWeight == Math.ceil(89*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(90*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(91*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-80%, Correct_Size_Second-50~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(92*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-73%, Correct_Size_Second-54~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(93*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-54~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == Math.ceil(94*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-54~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 207 && whatIsYOurWeight < 225){
          if(whatIsYOurWeight == Math.ceil(95*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == Math.ceil(96*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(97*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(98*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == Math.ceil(99*2.205) ) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == Math.ceil(100*2.205)) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == Math.ceil(101*2.205)) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }
      }

    }
    /**************************************************/
    if(!jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-WIYW").is(":checked")){
      if(jQuery.trim(whatIsYOurWeight_Unit) == "kg"){
        console.log("kg");
        jQuery("#measure_box_1").hide();
        console.log("weight is " + whatIsYOurWeight);
        if(whatIsYOurWeight > 65 && whatIsYOurWeight < 74){
          if(whatIsYOurWeight == 66) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 67) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-48~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 68) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-48~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 69) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-80%, Correct_Size_Second-48~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 70) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-73%, Correct_Size_Second-48~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 71) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-61%, Correct_Size_Second-48~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 72) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-58%, Correct_Size_Second-48~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 73) { Cookies.set('Popup_Second_Output', "Correct_Size_First-46~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 73 && whatIsYOurWeight < 82){
          if(whatIsYOurWeight == 74) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-46~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 75) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-46~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 76) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-46~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 77) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-80%, Correct_Size_Second-46~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 78) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-73%, Correct_Size_Second-50~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 79) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 80) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-58%, Correct_Size_Second-50~Prob_True_Second-42%"); }
          if(whatIsYOurWeight == 81) { Cookies.set('Popup_Second_Output', "Correct_Size_First-48~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 81 && whatIsYOurWeight < 89){
          if(whatIsYOurWeight == 82) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-48~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 83) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-48~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 84) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-48~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 85) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 86) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 87) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 88) { Cookies.set('Popup_Second_Output', "Correct_Size_First-50~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 88 && whatIsYOurWeight < 95){
          if(whatIsYOurWeight == 89) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-50~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 90) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-50~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 91) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-80%, Correct_Size_Second-50~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 92) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-73%, Correct_Size_Second-54~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 93) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-61%, Correct_Size_Second-54~Prob_True_Second-39%"); }
          if(whatIsYOurWeight == 94) { Cookies.set('Popup_Second_Output', "Correct_Size_First-52~Prob_True_First-55%, Correct_Size_Second-54~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight > 94 && whatIsYOurWeight < 102){
          if(whatIsYOurWeight == 95) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
          if(whatIsYOurWeight == 96) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 97) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 98) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-80%, Correct_Size_Second-52~Prob_True_Second-20%"); }
          if(whatIsYOurWeight == 99) { Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-73%, Correct_Size_Second-52~Prob_True_Second-27%"); }
          if(whatIsYOurWeight == 100){ Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-69%, Correct_Size_Second-52~Prob_True_Second-31%"); }
          if(whatIsYOurWeight == 101){ Cookies.set('Popup_Second_Output', "Correct_Size_First-54~Prob_True_First-55%, Correct_Size_Second-52~Prob_True_Second-45%"); }
        }
        if(whatIsYOurWeight <= 65 || whatIsYOurWeight >= 102){
          console.log('Weight Value not in range');
          Cookies.set('Popup_Second_Output', "null");
        }
      }
    }
  });
  // mobile only how old are you
  jQuery(document).on("keyup", ".measure_box_2_horu", function(){
    var firstInputValue = jQuery(".measure_box_1_horu").val();
    var howOldAreYou = jQuery(this).val();
    var howOldAreYouInt = firstInputValue+howOldAreYou;
    var Popup_Fourth_Output_Main = Cookies.get("Popup_Fourth_Output");
    // Correct_Size_First-46~Prob_True_First-36%, Correct_Size_Second-44~Prob_True_Second-64%
    //alert("main cookir get "+ Popup_Fourth_Output_Main);
    var Main_T_Cookie_Split = Popup_Fourth_Output_Main.split(",");

    var Main_T_Cookie_Split__0_a = Main_T_Cookie_Split[0];
    var Main_T_Cookie_Split__1_a = Main_T_Cookie_Split[1];

    var Main_T_Cookie_Split_First = Main_T_Cookie_Split__0_a.split("~");
    var Main_T_Cookie_Split_First0 = Main_T_Cookie_Split_First[0];
    var Main_T_Cookie_Split_First1 = Main_T_Cookie_Split_First[1];

    var Main_T_Cookie_Split_First_a = Main_T_Cookie_Split_First0.split("-");
    var Main_T_Cookie_Split_First_a_0 = Main_T_Cookie_Split_First_a[1];
    var Main_T_Cookie_Split_First_a_1 = parseInt(Main_T_Cookie_Split_First_a_0); // size 1

    if(typeof Main_T_Cookie_Split_First1 == 'undefined'){
      console.log('Main_T_Cookie_Split_First1 '+Main_T_Cookie_Split_First1);
      Cookies.set('Popup_Fifth_Output', "null");
      Popup_Fourth_Output_Main = 'null';
      if(howOldAreYou>20){
        jQuery('.TS-Fit-Submit button').removeAttr('disabled');
      }
    }

    /* initialised */

    var Main_T_Cookie_Split_First_b = "";
    var Main_T_Cookie_Split_First_b_0 = "";
    var Main_T_Cookie_Split_First_b_1 = "";
    var Main_T_Cookie_Split_Second = "";
    var Main_T_Cookie_Split_Second0 = "";
    var Main_T_Cookie_Split_Second1 = "";
    var Main_T_Cookie_Split_Second_a = "";
    var Main_T_Cookie_Split_Second_a_0 = "";
    var Main_T_Cookie_Split_Second_a_1 = "";
    var Main_T_Cookie_Split_Second_b = "";
    var Main_T_Cookie_Split_Second_b_0 = "";
    var Main_T_Cookie_Split_Second_b_1 = "";





    /* If fourth step cookie is not null */

    if(Popup_Fourth_Output_Main != 'null'){

      Main_T_Cookie_Split_First_b = Main_T_Cookie_Split_First1.split("-");
      Main_T_Cookie_Split_First_b_0 = Main_T_Cookie_Split_First_b[1]; 
      Main_T_Cookie_Split_First_b_1 = parseInt(Main_T_Cookie_Split_First_b_0); // probability 1


      Main_T_Cookie_Split_Second = Main_T_Cookie_Split__1_a.split("~");
      Main_T_Cookie_Split_Second0 = Main_T_Cookie_Split_Second[0];
      Main_T_Cookie_Split_Second1 = Main_T_Cookie_Split_Second[1];

      Main_T_Cookie_Split_Second_a = Main_T_Cookie_Split_Second0.split("-");
      Main_T_Cookie_Split_Second_a_0 = Main_T_Cookie_Split_Second_a[1];
      Main_T_Cookie_Split_Second_a_1 = parseInt(Main_T_Cookie_Split_Second_a_0); // size 2

      Main_T_Cookie_Split_Second_b = Main_T_Cookie_Split_Second1.split("-");
      Main_T_Cookie_Split_Second_b_0 = Main_T_Cookie_Split_Second_b[1];
      Main_T_Cookie_Split_Second_b_1 = parseInt(Main_T_Cookie_Split_Second_b_0); // probability 2

      //alert(Main_T_Cookie_Split_First_a_1 + " & " + Main_T_Cookie_Split_First_b_1 + " & " + Main_T_Cookie_Split_Second_a_1 + " & " +Main_T_Cookie_Split_Second_b_1);
      if(howOldAreYouInt<36){ 
        //alert("howOldAreYouInt"+ " & " +Main_T_Cookie_Split_First_b_1 + "--" + Main_T_Cookie_Split_Second_a_1);
        if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
          //alert("below thirty five first");
          var getFinalSizePlus  = Main_T_Cookie_Split_Second_b_1-5;
          var getFinalSizeMinus = Main_T_Cookie_Split_First_b_1+5;
          if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0;  //2
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;  //2
            if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizePlus+"%");
            }
          }
          if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0;  //2
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0;  //2
            if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizePlus+"%");
            }
          }
        }
        if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
          //alert("below thirty five second");
          //alert(Main_T_Cookie_Split_First_b_1);
          //alert(Main_T_Cookie_Split_Second_b_1);
          var getFinalSizePlus  = Main_T_Cookie_Split_First_b_1-5;
          var getFinalSizeMinus = Main_T_Cookie_Split_Second_b_1+5;
          //alert(getFinalSizePlus);
          //alert(getFinalSizeMinus);
          if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0; //2
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;  //2
            if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
            }
          }
          if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0; //2
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0; //2
            if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
            }
          }
        }
      }
      if(howOldAreYouInt>35){
        //alert("howOldAreYouInt>36");
        //alert(Main_T_Cookie_Split_First_b_1+ " &^& " +Main_T_Cookie_Split_Second_b_1);
        if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
          //alert("above thirty five first");
          var getFinalSizePlus  = Main_T_Cookie_Split_First_b_1+5;
          var getFinalSizeMinus = Main_T_Cookie_Split_Second_b_1-5;
          console.log("howOldAreYouInt>35 1 "+Main_T_Cookie_Split_First_a_1+" & "+Main_T_Cookie_Split_Second_a_1);
          console.log("howOldAreYouInt>35 1 (+5,-5) "+getFinalSizePlus+" & (-19) "+getFinalSizeMinus);        
          if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0;  //2
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0;  //2
            if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
            }
          }
          if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0;  //2
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;  //2
            if(isNaN(getFinalSizeMinus) || getFinalSizeMinus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizePlus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizeMinus+"%");
            }
          }
        }
        if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
          var getFinalSizePlus  = Main_T_Cookie_Split_Second_b_1+5;
          var getFinalSizeMinus = Main_T_Cookie_Split_First_b_1-5;
          //console.log("howOldAreYouInt>35 1 "+Main_T_Cookie_Split_First_a_1+" & "+Main_T_Cookie_Split_Second_a_1);
          //console.log("howOldAreYouInt>35 1 (+5,-5) "+getFinalSizePlus+" & (-19) "+getFinalSizeMinus); 
          //Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizePlus+"%");
          if(Main_T_Cookie_Split_First_a_1<Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_First_a_1+0;
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_Second_a_1-0;
            if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalPlus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalMinus+"~Prob_True_Second-"+getFinalSizePlus+"%");
            }
          }
          if(Main_T_Cookie_Split_First_a_1>Main_T_Cookie_Split_Second_a_1){
            var ansSizeBasedFinalPlus  = Main_T_Cookie_Split_Second_a_1+0;
            var ansSizeBasedFinalMinus = Main_T_Cookie_Split_First_a_1-0;
            if(isNaN(getFinalSizePlus) || getFinalSizePlus < 1){
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+"00"+"%");
            }else{
              Cookies.set('Popup_Fifth_Output', "Correct_Size_First-"+ansSizeBasedFinalMinus+"~Prob_True_First-"+getFinalSizeMinus+"%, Correct_Size_Second-"+ansSizeBasedFinalPlus+"~Prob_True_Second-"+getFinalSizePlus+"%");
            }
          }
        }   
      }
    }
  });


  // SCRIPT FOR RANGE MOBILE (TYPE RADIO BUTTON)
  //   jQuery(document).on("click", "label.radio_txt", function(){
  //     //     alert(jQuery(this).val());
  //     var c_Range_Main_Input_FP = jQuery(this).val();
  //     var c_Range_Main_Input__Attr_FP = jQuery.trim(jQuery(this).find("span.value_content").text());
  //     //console.log(c_Range_Main_Input_FP+" & "+c_Range_Main_Input__Attr_FP);
  //     alert(c_Range_Main_Input__Attr_FP);
  //     var Popup_Fifth_Output_Main_Final = Cookies.get("Popup_Fifth_Output");
  //     var Main_T_Cookie_Split_Final = Popup_Fifth_Output_Main_Final.split(",");

  //     var Main_T_Cookie_Split__0_a_Final = Main_T_Cookie_Split_Final[0];
  //     var Main_T_Cookie_Split__1_a_Final = Main_T_Cookie_Split_Final[1];

  //     var Main_T_Cookie_Split_First_Final = Main_T_Cookie_Split__0_a_Final.split("~");
  //     var Main_T_Cookie_Split_First0_Final = Main_T_Cookie_Split_First_Final[0];
  //     var Main_T_Cookie_Split_First1_Final = Main_T_Cookie_Split_First_Final[1];

  //     var Main_T_Cookie_Split_First_a_Final = Main_T_Cookie_Split_First0_Final.split("-");
  //     var Main_T_Cookie_Split_First_a_0_Final = Main_T_Cookie_Split_First_a_Final[1];
  //     var Main_T_Cookie_Split_First_a_1_Final = parseInt(Main_T_Cookie_Split_First_a_0_Final); // size 1

  //     var Main_T_Cookie_Split_First_b_Final = Main_T_Cookie_Split_First1_Final.split("-");
  //     var Main_T_Cookie_Split_First_b_0_Final = Main_T_Cookie_Split_First_b_Final[1]; 
  //     var Main_T_Cookie_Split_First_b_1_Final = parseInt(Main_T_Cookie_Split_First_b_0_Final); // probability 1


  //     var Main_T_Cookie_Split_Second_Final = Main_T_Cookie_Split__1_a_Final.split("~");
  //     var Main_T_Cookie_Split_Second0_Final = Main_T_Cookie_Split_Second_Final[0];
  //     var Main_T_Cookie_Split_Second1_Final = Main_T_Cookie_Split_Second_Final[1];

  //     var Main_T_Cookie_Split_Second_a_Final = Main_T_Cookie_Split_Second0_Final.split("-");
  //     var Main_T_Cookie_Split_Second_a_0_Final = Main_T_Cookie_Split_Second_a_Final[1];
  //     var Main_T_Cookie_Split_Second_a_1_Final = parseInt(Main_T_Cookie_Split_Second_a_0_Final); // size 2

  //     var Main_T_Cookie_Split_Second_b_Final = Main_T_Cookie_Split_Second1_Final.split("-");
  //     var Main_T_Cookie_Split_Second_b_0_Final = Main_T_Cookie_Split_Second_b_Final[1];
  //     var Main_T_Cookie_Split_Second_b_1_Final = parseInt(Main_T_Cookie_Split_Second_b_0_Final); // probability 2

  //     if(c_Range_Main_Input__Attr_FP=="TIGHT"){
  //       // probabilty based first one
  //       if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //         var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final+16;
  //         var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final-16;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //       }
  //       // probabilty based second one
  //       if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //         var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final+16;
  //         var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final-16;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //       }
  //     }

  //     if(c_Range_Main_Input__Attr_FP=="LITTLE TIGHT"){
  //       // probabilty based first one
  //       if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //         var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final+11;
  //         var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final-11;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
  //           } else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //       }
  //       // probabilty based second one
  //       if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //         var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final+11;
  //         var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final-11;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //       }
  //     }

  //     if(c_Range_Main_Input__Attr_FP=="NORMAL"){
  //       //alert(Main_T_Cookie_Split_First_a_1_Final+ " -- "+ Main_T_Cookie_Split_First_b_1_Final + " -- "+ Main_T_Cookie_Split_Second_a_1_Final + " -- "+ Main_T_Cookie_Split_Second_b_1_Final);
  //       Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+Main_T_Cookie_Split_First_a_1_Final+"~Prob_True_First-"+Main_T_Cookie_Split_First_b_1_Final+"%, Correct_Size_Second-"+Main_T_Cookie_Split_Second_a_1_Final+"~Prob_True_Second-"+Main_T_Cookie_Split_Second_b_1_Final+"%");
  //     }

  //     if(c_Range_Main_Input__Attr_FP=="LITTLE LOOSE"){
  //       // probabilty based first one
  //       if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //         //alert("first type of alert");
  //         var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final-11;
  //         var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final+11;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLargerSize+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLargerSize+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //       }
  //       // probabilty based second one
  //       if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //         //alert("second type of alert");
  //         var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final-11;
  //         var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final+11;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //       }
  //     }

  //     if(c_Range_Main_Input__Attr_FP=="LOOSE"){
  //       // probabilty based first one
  //       if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //         var AdditionInSmaller = Main_T_Cookie_Split_First_b_1_Final-16;
  //         var SubtructionInLarger = Main_T_Cookie_Split_Second_b_1_Final+16;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           if(isNaN(SubtructionInLarger) || SubtructionInLarger < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+AdditionInSmaller+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+SubtructionInLarger+"%");
  //           }
  //         }
  //       }
  //       // probabilty based second one
  //       if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //         var AdditionInSmaller = Main_T_Cookie_Split_Second_b_1_Final-16;
  //         var SubtructionInLarger = Main_T_Cookie_Split_First_b_1_Final+16;
  //         if(Main_T_Cookie_Split_First_a_1_Final<Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_First_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_Second_a_1_Final-0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+AdditionInSmallerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+SubtructionInLargerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //         if(Main_T_Cookie_Split_First_a_1_Final>Main_T_Cookie_Split_Second_a_1_Final){
  //           var AdditionInSmallerSize = Main_T_Cookie_Split_Second_a_1_Final+0;
  //           var SubtructionInLargerSize = Main_T_Cookie_Split_First_a_1_Final-0;
  //           if(isNaN(AdditionInSmaller) || AdditionInSmaller < 1){
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+"00"+"%");
  //           }else{
  //             Cookies.set('Popup_Sixth_Output', "Correct_Size_First-"+SubtructionInLargerSize+"~Prob_True_First-"+SubtructionInLarger+"%, Correct_Size_Second-"+AdditionInSmallerSize+"~Prob_True_Second-"+AdditionInSmaller+"%");
  //           }
  //         }
  //       }
  //     }
  //   });



  // range active class
  jQuery(document).on("click", "input#range-main-input-FP", function(){
    var rangeInputAttr = jQuery("input#range-main-input-FP").attr("fit-pref");
    jQuery("ul.desktop--only-ts.range-labels").find("li").each(function(){
      var currentRangeAttr = jQuery(this).attr("fit-attr");
      if(rangeInputAttr==currentRangeAttr){
        jQuery(this).addClass("selected active");
      }
      if(rangeInputAttr!=currentRangeAttr){
        jQuery(this).removeClass("selected active");
      }
    });
  });


  // animation jquery
  //   jQuery(document).on("keypress", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active input#range-main-input-FP", function (e) {
  //     if (e.keyCode == 13) {
  //       var Popup_Fifth_Output_Main_Final_a = Cookies.get("Popup_Sixth_Output");
  //       var Main_T_Cookie_Split_Final_a = Popup_Fifth_Output_Main_Final_a.split(",");

  //       var Main_T_Cookie_Split__0_a_Final_a = Main_T_Cookie_Split_Final_a[0];
  //       var Main_T_Cookie_Split__1_a_Final_a = Main_T_Cookie_Split_Final_a[1];

  //       var Main_T_Cookie_Split_First_Final_a = Main_T_Cookie_Split__0_a_Final_a.split("~");
  //       var Main_T_Cookie_Split_First0_Final_a = Main_T_Cookie_Split_First_Final_a[0];
  //       var Main_T_Cookie_Split_First1_Final_a = Main_T_Cookie_Split_First_Final_a[1];

  //       var Main_T_Cookie_Split_First_a_Final_a = Main_T_Cookie_Split_First0_Final_a.split("-");
  //       var Main_T_Cookie_Split_First_a_0_Final_a = Main_T_Cookie_Split_First_a_Final_a[1];
  //       var Main_T_Cookie_Split_First_a_1_Final_a = parseInt(Main_T_Cookie_Split_First_a_0_Final_a); // size 1

  //       var Main_T_Cookie_Split_First_b_Final_a = Main_T_Cookie_Split_First1_Final_a.split("-");
  //       var Main_T_Cookie_Split_First_b_0_Final_a= Main_T_Cookie_Split_First_b_Final_a[1]; 
  //       var Main_T_Cookie_Split_First_b_1_Final_a= parseInt(Main_T_Cookie_Split_First_b_0_Final_a); // probability 1


  //       var Main_T_Cookie_Split_Second_Final_a = Main_T_Cookie_Split__1_a_Final_a.split("~");
  //       var Main_T_Cookie_Split_Second0_Final_a = Main_T_Cookie_Split_Second_Final_a[0];
  //       var Main_T_Cookie_Split_Second1_Final_a = Main_T_Cookie_Split_Second_Final_a[1];

  //       var Main_T_Cookie_Split_Second_a_Final_a = Main_T_Cookie_Split_Second0_Final_a.split("-");
  //       var Main_T_Cookie_Split_Second_a_0_Final_a = Main_T_Cookie_Split_Second_a_Final_a[1];
  //       var Main_T_Cookie_Split_Second_a_1_Final_a = parseInt(Main_T_Cookie_Split_Second_a_0_Final_a); // size 2

  //       var Main_T_Cookie_Split_Second_b_Final_a = Main_T_Cookie_Split_Second1_Final_a.split("-");
  //       var Main_T_Cookie_Split_Second_b_0_Final_a = Main_T_Cookie_Split_Second_b_Final_a[1];
  //       var Main_T_Cookie_Split_Second_b_1_Final_a = parseInt(Main_T_Cookie_Split_Second_b_0_Final_a); // probability 2
  //       jQuery({ Counter: 0 }).animate({
  //         Counter: Main_T_Cookie_Split_First_b_1_Final_a
  //       }, {
  //         duration: 3000,
  //         easing: 'swing',
  //         step: function() {
  //           $('div#random__number_a').text(Math.ceil(this.Counter)+"%");
  //         }
  //       });

  //       jQuery({ Counter: 0 }).animate({
  //         Counter: Main_T_Cookie_Split_Second_b_1_Final_a
  //       }, {
  //         duration: 2000,
  //         easing: 'swing',
  //         step: function() {
  //           $('div#random__number_aa').text(Math.ceil(this.Counter)+"%");
  //         }
  //       });
  //     }
  //   });

  if(jQuery(window).width() > 767){
    // result with progress
    jQuery(document).on("click", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active label.radio_txt", function (eaaaaaaa) {
      if (eaaaaaaa.keyCode == 13) {
        jQuery("#random__number_a").css({"width": "0"});
        jQuery("#random__number_a").animate({width: jQuery("#random__number_a").text(), marginLeft: 0}, {duration: 2200});
        jQuery("#random__number_aa").css({"width": "0"});
        jQuery("#random__number_aa").animate({width: jQuery("#random__number_aa").text(), marginLeft: 0}, {duration: 2200});
        console.log('Niche se PB 2');
      }
    });
  }
  if(jQuery(window).width() < 768){
    jQuery(document).on("click", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active label.radio_txt", function (eaaaaaaa) {
      console.log("loader running");
      jQuery("#random__number_a").css({"width": "0"});
      jQuery("#random__number_a").animate({width: jQuery("#random__number_a").text(), marginLeft: 0}, {duration: 2200});
      jQuery("#random__number_aa").css({"width": 0});
      jQuery("#random__number_aa").animate({width: jQuery("#random__number_aa").text(), marginLeft: 0}, {duration: 1200});
      console.log('Niche se PB 1 :->'+jQuery("#random__number_aa").text());
    });
  }


  //jQuery( window ).resize(function() {
  // How tall are you? -- change attr placeholder
  if(jQuery(window).width() > 767){
    jQuery("input.measure_box__a_1").attr("placeholder","X");
    jQuery("input.measure_box_b_2").attr("placeholder","X");
    jQuery("input.measure_box__a_1").find("span").show();
    jQuery("input.measure_box_b_2").find("span").show();
    jQuery(document).on("click", "label.switch-HTAY.step-1", function(){
      var howTallYouAre1aaa = parseInt(jQuery(this).closest(".TS-FitFinder-HTAY").find(".input-type-HTAY").val());
      var howTallYouAre_Unit1aaa = Cookies.get('height-unit');
      Cookies.set('height-value', howTallYouAre1aaa+howTallYouAre_Unit1aaa);
      var currentUnitForTallerShorter1aaa = jQuery(this).attr("unit");
      // If CENTIMETERS
      if(!jQuery(this).closest(".TS-FitFinder-HTAY").find(".switch-WIYW-FitFinder").is(":checked")){
        jQuery(".switch-WIYW-FitFinder").show();
        jQuery("div#FitFinder-inches").hide();
        jQuery("input#input-type-HTAY-main").focus();
      }
      // If INCHES
      if(jQuery(this).closest(".TS-FitFinder-HTAY").find("input.checkbox-HTAY").is(":checked")){
        jQuery(".switch-WIYW-FitFinder").hide();
        jQuery("div#FitFinder-inches").show();
        jQuery(".measure_box__a_1").focus();
      }
    });
  }
  if(jQuery(window).width() > 767){
    jQuery("div#FitFinder-inches").find("span").show();
  }
  if(jQuery(window).width() < 768){
    jQuery("div#FitFinder-inches").find("span").hide();
  }
  //});
  // Belly Container
  jQuery(document).on("click", "div#TS-FitFinder--TS-3 button:nth-child(1)", function(){
    jQuery('.Belly-container[belly-main-type="Flatter"]').click();
    jQuery('.Belly-container[belly-main-type="Flatter"]').trigger("click");
  });
  jQuery(document).on("click", "div#TS-FitFinder--TS-3 button:nth-child(2)", function(){
    jQuery('.Belly-container[belly-main-type="Average"]').click();
    jQuery('.Belly-container[belly-main-type="Average"]').trigger("click");
  });
  jQuery(document).on("click", "div#TS-FitFinder--TS-3 button:nth-child(3)", function(){
    jQuery('.Belly-container[belly-main-type="Rounder"]').click();
    jQuery('.Belly-container[belly-main-type="Rounder"]').trigger("click");
  });

  // Shoulder Width Container
  jQuery(document).on("click", "div#TS-FitFinder--TS-4 button:nth-child(1)", function(){
    jQuery('.Shoulder-width-container[shoulder-main-type="Narrow"]').click();
    jQuery('.Shoulder-width-container[shoulder-main-type="Narrow"]').trigger("click");
  });
  jQuery(document).on("click", "div#TS-FitFinder--TS-4 button:nth-child(2)", function(){
    jQuery('.Shoulder-width-container[shoulder-main-type="Narrow"]').click();
    jQuery('.Shoulder-width-container[shoulder-main-type="Narrow"]').trigger("click");
  });
  jQuery(document).on("click", "div#TS-FitFinder--TS-4 button:nth-child(3)", function(){
    jQuery('.Shoulder-width-container[shoulder-main-type="Narrow"]').click();
    jQuery('.Shoulder-width-container[shoulder-main-type="Narrow"]').trigger("click");
  });

  // mobile slider button
  /*jQuery(document).on("click", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active button", function (e) {
        console.log(jQuery(this).html());
        if(jQuery(window).width() < 768){
          setTimeout(function(){
            var now_active = jQuery('.FitFinder-Active').attr('data-step');
            console.log('Now Active Step:--'+now_active);
            if(now_active == 'step-4'){
              jQuery('.steps-HTAY .round-all[data-step="step-4"]').trigger('click');
            }
            if(now_active == 'step-5'){
              jQuery('.steps-HTAY .round-all[data-step="step-5"]').trigger('click');
            }
          },100);
        }
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('FitFinder-Active');
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').next('.TS-FitFinder-HTAY').addClass('fadeInRight animated');
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('FitFinder-Active');
        jQuery(this).parents('.TS-FitFinder-HTAY.FitFinder-Active').removeClass('fadeInRight animated');
      });*/


  // CHECKBOX CHECKED AND UNCHECKED MOUSEMOVE
  jQuery(document).on("mousemove", "body", function(){
    var checkboxValueChanging = jQuery("input.checkbox-HTAY").val();
    if(checkboxValueChanging=="-cm"){
      jQuery("input.checkbox-HTAY").prop("checked", false);
    }
    if(checkboxValueChanging=="-in"){
      jQuery("input.checkbox-HTAY").prop("checked", true);
    }
  });
  jQuery(document).on("mousemove", "body", function(){
    var checkboxValueChanging_WEIGHT = jQuery("input.checkbox-WIYW").val();
    if(checkboxValueChanging_WEIGHT =="-kg"){
      jQuery("input.checkbox-WIYW").prop("checked", false);
    }
    if(checkboxValueChanging_WEIGHT =="-lbs"){
      jQuery("input.checkbox-WIYW").prop("checked", true);
    }
  });



  // CHECKBOX CHECKED AND UNCHECKED KEYPRESS
  jQuery(document).on("keypress", "body", function(){
    var checkboxValueChanging_GLM  = jQuery("input.checkbox-HTAY").val();
    if(checkboxValueChanging_GLM =="-cm"){
      jQuery("input.checkbox-HTAY").prop("checked", false);
    }
    if(checkboxValueChanging_GLM =="-in"){
      jQuery("input.checkbox-HTAY").prop("checked", true);
    }
  });
  jQuery(document).on("keypress", "body", function(){
    var checkboxValueChanging_WEIGHT_GLM = jQuery("input.checkbox-WIYW").val();
    if(checkboxValueChanging_WEIGHT_GLM =="-kg"){
      jQuery("input.checkbox-WIYW").prop("checked", false);
    }
    if(checkboxValueChanging_WEIGHT_GLM =="-lbs"){
      jQuery("input.checkbox-WIYW").prop("checked", true);
    }
  });

  jQuery(document).on("keypress", ".TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active input#input-type-WIYW-main", function (eaaaaaaa) {
    //alert("div#TS-FitFinder--TS-3 .owl-stage-outer");
    if (eaaaaaaa.keyCode == 13) {
      setTimeout(function(){
        jQuery("div#TS-FitFinder--TS-3 .owl-stage-outer").css({"opacity":"1"});
      }, 500);
    }
  });
  jQuery(document).on('keypress', '.TS-FitFinder-Main .TS-FitFinder-HTAY.FitFinder-Active input[type="radio"]', function (eaaaaaaa) {
    //alert("div#TS-FitFinder--TS-4 .owl-stage-outer");
    if (eaaaaaaa.keyCode == 13) {
      setTimeout(function(){
        jQuery("div#TS-FitFinder--TS-4 .owl-stage-outer").css({"opacity":"1"});
      }, 500);
    }
  });


  /*  On click the continue button  */

  jQuery('.TS-Fit-Submit button[type="button"]').on('click',function(){
    console.log('clicked continue');
    if(jQuery(window).width() >= 768){
      console.log('on click width is greater than or equal to 768');
      var activeInput_Class = jQuery('.FitFinder-Active').find('input').attr('class');
      var input_type = jQuery('.FitFinder-Active').find('input').attr('type');
      console.log('clicked type '+input_type);
      /* If the input type is Text */
      if(input_type == 'text'){
        console.log('Input Type------ Text -----');
        var input_val = jQuery('.FitFinder-Active').find('input').val();
        if(input_val != ''){
          console.log('Not blank');
          var d_step = jQuery('.FitFinder-Active').attr('data-step');
          console.log(jQuery('.FitFinder-Active').attr('data-step'));
          if(d_step == 'step-1'){
            jQuery('.steps-HTAY .round-all[data-step="step-2"]').trigger('click');
          }
          if(d_step == 'step-2'){
            jQuery('.steps-HTAY .round-all[data-step="step-3"]').trigger('click');
          }
          if(d_step == 'step-3'){
            jQuery('.steps-HTAY .round-all[data-step="step-4"]').trigger('click');
          }
          if(d_step == 'step-4'){
            jQuery('.steps-HTAY .round-all[data-step="step-5"]').trigger('click');
            jQuery('.TS-FitFinder-HTAY.TS-5 .desktop--only-ts input').focus();
          }
          if(d_step == 'step-5'){
            jQuery('.steps-HTAY .round-all[data-step="step-6"]').trigger('click');
          }
          if(d_step == 'step-6'){
            jQuery('.steps-HTAY .round-all[data-step="step-7"]').trigger('click');
            jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
          }
        }else{
          console.log('blank');
        }
      }
      /* If the input type is Radio */
      if(input_type == 'radio'){
        var radio_class = jQuery('.FitFinder-Active .mobile--only-ts').find('input').attr('class');
        if(radio_class != activeInput_Class){
          console.log('Input Type------ Radio -----');
          if(jQuery('.FitFinder-Active').find('input[type="radio"]').is(":checked")){
            console.log('Not blank');
            var d_step = jQuery('.FitFinder-Active').attr('data-step');
            console.log(jQuery('.FitFinder-Active').attr('data-step'));
            if(d_step == 'step-1'){
              jQuery('.steps-HTAY .round-all[data-step="step-2"]').trigger('click');
            }
            if(d_step == 'step-2'){
              jQuery('.steps-HTAY .round-all[data-step="step-3"]').trigger('click');
            }
            if(d_step == 'step-3'){
              jQuery('.steps-HTAY .round-all[data-step="step-4"]').trigger('click');
            }
            if(d_step == 'step-4'){
              jQuery('.steps-HTAY .round-all[data-step="step-5"]').trigger('click');
            }
            if(d_step == 'step-5'){
              jQuery('.steps-HTAY .round-all[data-step="step-6"]').trigger('click');
            }
            if(d_step == 'step-6'){
              jQuery('.steps-HTAY .round-all[data-step="step-7"]').trigger('click');
              jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
            }
          }else{
            console.log('blank');
          }
        }


      }	
      /*  If the input type is Range */
      //var input_type_range = jQuery('.FitFinder-Active .desktop--only-ts').find('input').attr('type');
      if(input_type == 'range'){
        console.log('Input Type------ Range -----');
        if(jQuery('.FitFinder-Active').find('input[type="range"]') != ''){
          console.log('Not blank');
          var d_step = jQuery('.FitFinder-Active').attr('data-step');
          console.log(jQuery('.FitFinder-Active').attr('data-step'));
          if(d_step == 'step-1'){
            jQuery('.steps-HTAY .round-all[data-step="step-2"]').trigger('click');
          }
          if(d_step == 'step-2'){
            jQuery('.steps-HTAY .round-all[data-step="step-3"]').trigger('click');
          }
          if(d_step == 'step-3'){
            jQuery('.steps-HTAY .round-all[data-step="step-4"]').trigger('click');
          }
          if(d_step == 'step-4'){
            jQuery('.steps-HTAY .round-all[data-step="step-5"]').trigger('click');
          }
          if(d_step == 'step-5'){
            jQuery('.steps-HTAY .round-all[data-step="step-6"]').trigger('click');
          }
          if(d_step == 'step-6'){
            jQuery('.steps-HTAY .round-all[data-step="step-7"]').trigger('click');
            jQuery("button.btn").css("opacity", 1);
            //               jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
            jQuery('.steps-HTAY').hide();
          }
        }else{
          console.log('blank');
        }


      }	
    }else{
      console.log('On click width is less than 768');
      var step_indexes = jQuery('.FitFinder-Active').attr('data-step');
      console.log('data-step '+step_indexes);
      if(step_indexes == 'step-1'){
        jQuery('.steps-HTAY .round-all[data-step="step-2"]').trigger('click');
        console.log('Mobile --- First step');
        console.log('circle 2');
      }

      if(step_indexes == 'step-2'){
        jQuery('.steps-HTAY .round-all[data-step="step-3"]').trigger('click');
        console.log('Mobile --- Second step');
        console.log('circle 3');
      }
      if(step_indexes == 'step-3'){
        jQuery('.TS-FitFinder-HTAY.TS-3 button.owl-dot.active').trigger('click');
        setTimeout(function(){
          jQuery('.steps-HTAY .round-all[data-step="step-4"]').trigger('click');
          console.log('Mobile --- Second step');
          console.log('circle 4');
        },20);
      }
      if(step_indexes == 'step-4'){
        jQuery('.TS-FitFinder-HTAY.TS-4 button.owl-dot.active').trigger('click');
        setTimeout(function(){
          jQuery('.steps-HTAY .round-all[data-step="step-5"]').trigger('click');
          console.log('Mobile --- Second step');
          console.log('circle 5');
        },20);
      }
      if(step_indexes == 'step-5'){
        jQuery('.steps-HTAY .round-all[data-step="step-6"]').trigger('click');
        console.log('Mobile --- fifth step');
        console.log('circle 6');
      }
      if(step_indexes == 'step-6'){
        //             jQuery('input.fittingtype:checked').trigger('click');
        jQuery('.main-steps--HTAY .step-7').trigger('click');
        console.log('clicked input checkbox');

      }


      //           setTimeout(function(){
      //             var newstep_index = jQuery('.FitFinder-Active').attr('data-step');
      //             console.log('when step 3 and 4, Step indexe is :- '+newstep_index);
      //             if(newstep_index == 'step-3' || newstep_index == 'step-4'){
      //               jQuery('.TS-Fit-Submit button[type="button"]').attr('disabled','disabled');
      //               console.log('Mobile --- 3 and 4 step');
      //             }
      //           },100);
    }


  });





  /*================================= slick Slider Begin ==================================*/




  /* On change of slide get value */
  /*
      $('.fitslider').on('afterChange', function(event, slick, currentSlide){
        var label = $(this).parents('.sliderWrapper').attr('data-label');
        // Height 
        if(label == 'height'){
          var height = [];
          $('.sliderHeight .fitslider').each(function(){

            //console.log($(this).find('.slick-slide.slick-current.slick-active').attr('data-slick-index'));
            height.push($(this).find('.slick-slide.slick-current.slick-active').attr('data-slick-index'));

          });
          var Height = parseInt((height.toString()).replace(/\,/g,''));
          console.log('The Height is:-'+Height);
        }
        // Weight 
        if(label == 'weight'){
          var weight = [];
          $('.sliderWeight .fitslider').each(function(){

            //console.log($(this).find('.slick-slide.slick-current.slick-active').attr('data-slick-index'));
            weight.push($(this).find('.slick-slide.slick-current.slick-active').attr('data-slick-index'));

          });
          var Weight = parseInt((weight.toString()).replace(/\,/g,''));
          console.log('The Weight is:-'+Weight);
        }

      });*/
  /* height when swiper is scrolled  */
  /* for slider 1 */


  jQuery('.sliderHeight .fitslider.slider1').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Index and update measure input box */
    jQuery('div#FitFinder-centimeter input.measure_box_1').val(currentSlide);
    jQuery('div#FitFinder-centimeter input.measure_box_1').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('div#FitFinder-centimeter input.measure_box_1').val();
      var inpt_val2 = jQuery('div#FitFinder-centimeter input.measure_box_2').val();
      var inpt_val3 = jQuery('div#FitFinder-centimeter input.measure_box_3').val();
      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }
      if(inpt_val3 == ''){
        inpt_val3 = 0;
      }

      console.log(inpt_val1+' _/\_ '+inpt_val2+' _/\_ '+inpt_val3);
      var inpt_Total = parseInt(inpt_val1+inpt_val2+inpt_val3);
      console.log(inpt_Total);

      if(inpt_Total>100 && jQuery('div#FitFinder-centimeter input.measure_box_1').val() != '' && jQuery('div#FitFinder-centimeter input.measure_box_2').val() != ''&& jQuery('div#FitFinder-centimeter input.measure_box_3').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });

  /* for Slider 2 */
  jQuery('.sliderHeight .fitslider.slider2').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Index and update measure input box */
    jQuery('div#FitFinder-centimeter input.measure_box_2').val(currentSlide);
    jQuery('div#FitFinder-centimeter input.measure_box_2').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('div#FitFinder-centimeter input.measure_box_1').val();
      var inpt_val2 = jQuery('div#FitFinder-centimeter input.measure_box_2').val();
      var inpt_val3 = jQuery('div#FitFinder-centimeter input.measure_box_3').val();
      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }
      if(inpt_val3 == ''){
        inpt_val3 = 0;
      }

      console.log(inpt_val1+' _/\_ '+inpt_val2+' _/\_ '+inpt_val3);
      var inpt_Total = parseInt(inpt_val1+inpt_val2+inpt_val3);
      console.log(inpt_Total);

      if(inpt_Total>100 && jQuery('div#FitFinder-centimeter input.measure_box_1').val() != '' && jQuery('div#FitFinder-centimeter input.measure_box_2').val() != ''&& jQuery('div#FitFinder-centimeter input.measure_box_3').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });
  /* for Slider 3 */
  jQuery('.sliderHeight .fitslider.slider3').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Index and update measure input box */
    jQuery('div#FitFinder-centimeter input.measure_box_3').val(currentSlide);
    jQuery('div#FitFinder-centimeter input.measure_box_3').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('div#FitFinder-centimeter input.measure_box_1').val();
      var inpt_val2 = jQuery('div#FitFinder-centimeter input.measure_box_2').val();
      var inpt_val3 = jQuery('div#FitFinder-centimeter input.measure_box_3').val();
      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }
      if(inpt_val3 == ''){
        inpt_val3 = 0;
      }

      console.log(inpt_val1+' _/\_ '+inpt_val2+' _/\_ '+inpt_val3);
      var inpt_Total = parseInt(inpt_val1+inpt_val2+inpt_val3);
      console.log(inpt_Total);

      if(inpt_Total>100 && jQuery('div#FitFinder-centimeter input.measure_box_1').val() != '' && jQuery('div#FitFinder-centimeter input.measure_box_2').val() != ''&& jQuery('div#FitFinder-centimeter input.measure_box_3').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });

  /* Weight when swiper is scrolled  */
  /* for slider 1 */
  jQuery('.sliderWeight .fitslider.slider1').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Index and update measure input box */
    jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').val(currentSlide);
    jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').val();
      var inpt_val2 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').val();
      var inpt_val3 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').val();
      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }
      if(inpt_val3 == ''){
        inpt_val3 = 0;
      }

      console.log(inpt_val1+' _/\_ '+inpt_val2+' _/\_ '+inpt_val3);
      var inpt_Total = parseInt(inpt_val1+inpt_val2+inpt_val3);
      console.log(inpt_Total);

      if(inpt_Total>20 && jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').val() != '' && jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').val() != ''&& jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });

  /* for Slider 2 */
  jQuery('.sliderWeight .fitslider.slider2').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Indeinput.measure_box_1_wiywe input box */
    jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').val(currentSlide);
    jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').val();
      var inpt_val2 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').val();
      var inpt_val3 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').val();
      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }
      if(inpt_val3 == ''){
        inpt_val3 = 0;
      }

      console.log(inpt_val1+' _/\_ '+inpt_val2+' _/\_ '+inpt_val3);
      var inpt_Total = parseInt(inpt_val1+inpt_val2+inpt_val3);
      console.log(inpt_Total);

      if(inpt_Total>20 && jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').val() != '' && jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').val() != ''&& jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });
  /* for Slider 3 */
  jQuery('.sliderWeight .fitslider.slider3').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Index and update measure input box */
    jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').val(currentSlide);
    jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').val();
      var inpt_val2 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').val();
      var inpt_val3 = jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').val();
      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }
      if(inpt_val3 == ''){
        inpt_val3 = 0;
      }

      console.log(inpt_val1+' _/\_ '+inpt_val2+' _/\_ '+inpt_val3);
      var inpt_Total = parseInt(inpt_val1+inpt_val2+inpt_val3);
      console.log(inpt_Total);

      if(inpt_Total>20 && jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_1_wiyw').val() != '' && jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_2_wiyw').val() != ''&& jQuery('.TS-FitFinder-Mobile.WIYW-popup.mobile--only-ts input.measure_box_3_wiyw').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });


  /* Age when swiper is scrolled  */
  /* for slider 1 */
  jQuery('.sliderAge .fitslider.slider1').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Index and update measure input box */
    jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_1_horu').val(currentSlide);
    jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_1_horu').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_1_horu').val();
      var inpt_val2 = jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_2_horu').val();

      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }


      console.log(inpt_val1+' _/\_ '+inpt_val2);
      var inpt_Total = parseInt(inpt_val1+inpt_val2);
      console.log(inpt_Total);

      if(inpt_Total>20 && jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_1_horu').val() != '' && jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_2_horu').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });

  /* for Slider 2 */
  jQuery('.sliderAge .fitslider.slider2').on('afterChange', function(event, slick, currentSlide){
    /* Get current Slide Indeinput.measure_box_1_wiywe input box */
    jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_2_horu').val(currentSlide);
    jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_2_horu').trigger('keyup');
    setTimeout(function(){
      var inpt_val1 = jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_1_horu').val();
      var inpt_val2 = jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_2_horu').val();

      if(inpt_val1 == ''){
        inpt_val1 = 0;
      }
      if(inpt_val2 == ''){
        inpt_val2 = 0;
      }


      console.log(inpt_val1+' _/\_ '+inpt_val2);
      var inpt_Total = parseInt(inpt_val1+inpt_val2);
      console.log(inpt_Total);

      if(inpt_Total>20 && jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_1_horu').val() != '' && jQuery('.TS-FitFinder-Mobile.HORU-popup.mobile--only-ts input.measure_box_2_horu').val() != ''){
        console.log('removed disabled from continue button');
        jQuery('.TS-Fit-Submit button.btn').removeAttr('disabled');
      }else{
        console.log('disabled continue button');
        jQuery('.TS-Fit-Submit button.btn').attr('disabled','disabled');
      }
    },100);
  });






  /*================================= slick Slider Ends ===================================*/

});





// on load scripts
jQuery(window).on("load", function(){
  /* default settings */
  jQuery('div#TS-FitFinder--TS-3 .owl-stage-outer,div#TS-FitFinder--TS-4 .owl-stage-outer').css({'opacity':'1'});

  Cookies.set('height-unit', 'cm');
  Cookies.set('weight-unit', 'kg');
  Cookies.set('result-value', 0);
  Cookies.set('Popup_First_Output', "-----------------------"); // => false
  Cookies.set('Popup_Second_Output', "-----------------------"); // => false
  Cookies.set('Popup_Third_Output', "-----------------------"); // => false
  Cookies.set('Popup_Fourth_Output', "-----------------------"); // => false
  Cookies.set('Popup_Fifth_Output', "-----------------------"); // => false
  Cookies.set('Popup_Sixth_Output', "-----------------------"); // => false
});  


